# App Connect Connector Skills

A Claude Code / Cowork plugin that helps build [RingCentral App Connect](https://appconnect.labs.ringcentral.com) CRM connectors — the pluggable integrations that let RingEX log calls, texts, and appointments into a third-party CRM.

## Architecture

One orchestrator skill sequences nine feature-area skills, plus a standalone pre-build assessment skill that sits outside that pipeline:

```
appconnect-readiness             (standalone — run before committing to a build)

appconnect-build-connector      (orchestrator — start here for the build itself)
├── appconnect-setup            project scaffold, deps, manifest registration
├── appconnect-auth             auth type, env vars, auth interfaces
├── appconnect-local-testing    ngrok tunnel, Developer Console registration, live login test
├── appconnect-contact-matching findContact / findContactWithName / createContact
├── appconnect-call-logging     createCallLog / updateCallLog / getCallLog / getLogFormatType / upsertCallDisposition
├── appconnect-sms-logging      createMessageLog / updateMessageLog
├── appconnect-appointments     appointment CRUD interfaces
├── appconnect-settings-admin   custom settings, per-user license gating, managed auth options
├── appconnect-server-logging   serverSideLogging manifest toggle, getServerLoggingSettings / updateServerLoggingSettings / getUserList
├── appconnect-deploy           deploy-target cleanup (AWS Lambda / Azure App Service / Heroku)
└── appconnect-code-review      (optional) security, performance, idiomatic-pattern, and naming review
```

Before interviewing, the orchestrator's Step 1 now checks whether a readiness report already exists for the named CRM (`docs/APPCONNECT_READINESS.md` in an existing project, or `appconnect-readiness-<crm-key>.md` in the working directory). If found, it pre-fills the interview from that report's recommendations; if not, it asks the user whether to run `appconnect-readiness` first before scaffolding. The orchestrator then interviews the user (connector name, target CRM, auth type, which optional features are in scope), confirms a plan, then walks through the relevant sub-skills in order. Each sub-skill is self-contained and can also be invoked directly if the user only needs help with one piece (e.g. "add SMS logging to my Foo connector").

Once `appconnect-deploy` reports the build complete, the orchestrator offers one more, purely optional pass: `appconnect-code-review`. Unlike the other sub-skills, it's never part of the Step 2 interview checklist and isn't pre-seeded into `PROGRESS.md`'s plan — it's offered fresh after there's finished code to review, and only runs if the user opts in. It reads the generated connector project for hardcoded secrets, missing input validation, redundant/blocking API calls, patterns that diverge from the reference connectors, and inconsistent naming, then reports findings by severity and only edits files for the ones the user confirms. It can also be invoked standalone against any already-scaffolded connector, outside the build pipeline entirely.

`appconnect-readiness` itself is still optional and never invoked automatically — the orchestrator only checks for its *output* and offers to run it, it doesn't run it unprompted. Give the skill a CRM's OpenAPI/Swagger spec and it produces a structured, durable readiness report — which endpoints satisfy which App Connect capability (auth, contact lookup, call logging, message logging, appointments, admin settings), each rated Verified / Inferred / Gap with a concrete workaround where one exists. It never scaffolds a project or writes `PROGRESS.md`; its report is meant to be handed to `appconnect-build-connector` as an input once the user decides to proceed. See `skills/appconnect-readiness/SKILL.md` for the full depth-level (quick/standard/comprehensive) and capability-checklist details.

## Source of truth

These skills encode patterns learned from the `rc-unified-crm-extension` repo (the App Connect reference implementation): `docs/developers/*` for interface contracts and `src/connectors/{pipedrive,clio,bullhorn}` for working examples. When a skill needs precise, current detail (exact function signatures, manifest fields, env var naming), it should re-check those docs in the checked-out App Connect repo if the user has one open, rather than relying solely on what's baked into the skill — the docs are the authority and may move ahead of this skill set.

## Guardrails

- These skills never modify the App Connect extension's own source code as a side effect of running. They operate on whatever connector project the user has open (a fresh scaffold, or a connector directory within a checkout of the extension repo).
- Secrets (client IDs/secrets, API keys) are always collected as environment variables — never hardcoded into connector source or committed.
- Skills should ask before making destructive changes (overwriting an existing connector file, changing manifest entries for a connector that already exists).

## Status

Scaffolded 2026-08-23. The orchestrator and all six build-pipeline sub-skills exist as working drafts based on App Connect docs research; they haven't yet been run against a real connector build or iterated with `skill-creator` evals. Treat generated code as a strong starting point that still needs review against the live docs.

`appconnect-readiness` was added 2026-08-24 and has been through one `skill-creator` eval iteration (2 test cases, both at 100% assertion pass rate against synthetic OpenAPI3/Swagger2 fixtures — real-world spec smoke testing was blocked by sandbox network restrictions during development and is still outstanding). A controlled depth-level test (same spec at quick/standard/comprehensive) showed only a marginal tool-call-count difference (9/10/11) on a small 4-operation fixture — likely needs a larger spec to demonstrate the intended cost escalation clearly.

`appconnect-build-connector` was updated 2026-08-24 (v0.2.1) to add a Step 1 pre-interview check for an existing `appconnect-readiness` report, closing the gap noted in `appconnect-readiness`'s own "Non-goals reminder."

`appconnect-local-testing` was added 2026-08-24 (v0.3.0) and inserted into the pipeline between `appconnect-auth` and `appconnect-contact-matching`. Auth being unverified against a real client was a gap every downstream skill silently inherited — this closes it by walking the user through standing up ngrok, registering the connector in the Developer Console, and confirming login actually works end-to-end before any further interface work starts. `appconnect-setup`'s handoff note and `appconnect-contact-matching`'s frontmatter were both updated to reflect the new ordering.

`appconnect-server-logging` was split out of `appconnect-settings-admin` on 2026-08-26. Server-side logging (the `serverSideLogging` manifest block plus `getServerLoggingSettings`/`updateServerLoggingSettings`/`getUserList`) had grown enough surface area — a toggle-only tier vs. a full credential-storage-and-user-mapping tier — to warrant its own skill rather than staying a subsection of the settings-admin grab-bag. `appconnect-settings-admin` now covers only custom settings, per-user license gating (`getLicenseStatus`), and dynamic managed-auth options; `appconnect-build-connector`'s interview, `PROGRESS.md` template, and Step 5 sequence were updated to run the new skill after `appconnect-call-logging` (it reuses `createCallLog`/`updateCallLog` rather than defining new logging logic).

`appconnect-code-review` was added 2026-08-27 as an optional final pass after `appconnect-deploy`. It reviews the generated connector for security vulnerabilities, performance/optimization opportunities, non-idiomatic patterns (compared against the reference connectors), and poor or inconsistent naming — reporting findings by severity and only editing files the user confirms. It's never part of the Step 2 interview or pre-seeded into `PROGRESS.md`'s plan; `appconnect-build-connector` offers it fresh once `## Status` reads `Build complete`, and it can also run standalone against any already-scaffolded connector.
