# Shared reference: manually editing a connector via the Developer Console

Handing the user a fresh `manifest.json` to paste into the console's **View source** JSON
editor (see `appconnect-local-testing` Step 7) is the fastest path for a brand-new
connector, but it doesn't always work for an *update* to an already-registered one — the
user may only have the guided form open, may not want to risk overwriting unrelated
manifest content with a stale local copy, or the console session may simply not offer
the JSON view at that moment. Any skill that just wrote a manifest field should also be
able to tell the user exactly which guided-form field to click, instead of only offering
"paste this JSON." This doc is that field-by-field map — link here rather than
re-deriving the console's layout from scratch.

## Provenance and caveats — read before quoting this as gospel

This mapping was reverse-engineered from a single MHTML snapshot of one connector's
**Settings** screen (`https://appconnect.labs.ringcentral.com/console#/app/connectors/...`),
captured 2026-08-26, with **Authentication type = OAuth**. That means:

- The **Overview** tab (a sibling of Settings in the left nav) isn't covered at all — no
  data available for it.
- **Custom settings** and **Admin settings** were expanded but had no rows configured, so
  only their entry-point buttons and helper text are documented — the sub-fields that
  appear after clicking "Add Setting Section" / "Add standalone setting" / "Add account
  data source" are not visible in this snapshot.
- The **Associated ticket – Selection Dropdown** field editor was collapsed under "call
  logging page" but expanded under "message logging page" — both are documented as one
  entry since they're the same field-type editor, but this should be spot-checked live.
- Only the **OAuth** variant of the Authentication section is covered. If the target
  connector uses **Static credentials**, the fields will differ — confirm live rather
  than assuming the OAuth field list applies.
- The **Scope** value shown was truncated mid-string in the DOM — never transcribe an
  exact scope string from this doc; always get it from the live console or the
  connector's own manifest.
- Section-local **Save** buttons appear on the call-logging-page, message-logging-page,
  and server-side-logging subsections, distinct from the master **Save** button at the
  bottom of the page. Whether these commit independently or are purely cosmetic
  scroll-anchors wasn't verified — treat local saves as real commits until confirmed
  otherwise.

If anything below doesn't match what's actually on screen, trust the live console over
this doc, and flag the mismatch so this file can be corrected — don't silently route
around it in just one skill.

## Navigation

Every field lives on one continuously-scrolling **Settings** screen for the connector
(`Home > <Connector name> > Settings`), not separate tabs. Fields are grouped under three
visual group headings — **App integration**, **Customize your adapter**, **Support** —
each containing collapsible accordion sections. A single master **Save** button at the
bottom of the page commits the whole screen.

## App integration

### Connector details → top-level `manifest.json` fields

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Connector name * | text | `name` |
| Unique identifier * | text, locked after creation | connector id (the `platforms.<key>` key) |
| Connector server mode | radio: App Connect framework / Proxy to existing APIs | server implementation mode (code connector vs. proxy connector) |
| Connector server URL * | text, must be HTTPS, no trailing slash | `serverUrl` |
| Description | text | `description` |
| Version | text, SemVer | `version` |
| Icon URL | text, 200x200px | `icon` |
| License type | radio: Free / Paid | license/monetization flag |

Owned by `appconnect-setup` (initial values) and `appconnect-local-testing` (the
`serverUrl` update every time the ngrok tunnel restarts — see that skill's Step 4/5
caveat about re-pointing this field without needing to recreate the connector).

### Platform URLs → `crmUrl`, `environment`, embed/setup config

| Console field | Type | manifest.json field |
| --- | --- | --- |
| CRM URL type | radio: Fixed / Selectable / Tenant-specific | `environment.type`: `fixed` / `selectable` / `dynamic` |
| CRM URL * | text, wildcards supported | `crmUrl` |
| Setup page instructions | repeatable text list ("Add" button) | `environment.instructions` (dynamic/tenant-specific setup copy) |
| Setup page preview | test-only "Input hostname" field + Next button | not persisted — live simulation only |
| Default embed URLs | repeatable text list ("Add" button) | `embedUrls[]` |

Owned by `appconnect-auth` (environment type/CRM URL are decided in that skill's Step 3,
and `embedUrls` is called out explicitly in its pre-flight checklist).

### Authentication → `auth` / `platforms[x].auth`

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Authentication type * | radio: OAuth / Static credentials | `auth.type`: `oauth` / `apiKey` |
| Admin-managed OAuth credentials | checkbox | admin-managed OAuth credential flag |
| Auth URL * | text | `auth.oauth.authUrl` |
| Client ID * | text | `auth.oauth.clientId` |
| Redirect URI * | text | `auth.oauth.redirectUri` (the **nested** one) |
| Custom state | text | `auth.oauth.customState` |
| Scope | text | `auth.oauth.scope` |

Owned by `appconnect-auth`. **Open question — not yet confirmed:** this snapshot didn't
show a separate control for the *top-level* `AppConnectManifest.redirectUri` (distinct
from the nested `platforms[x].auth.oauth.redirectUri` documented in `appconnect-auth`'s
pre-flight checklist as the field the extension's OAuth-completion polling actually
reads). Don't assume the guided form's single "Redirect URI" field writes both, or that
the top-level field is exposed here at all — if a manifest-pasted top-level `redirectUri`
ever needs to be replicated through this guided form, verify live (or fall back to
**View source** for that one field) before telling a user it's covered by the field
above.

When Authentication type is set to **Static credentials** instead, this section will
show `apiKey`-related fields (likely a header/scheme and a login-form field list mapping
to `auth.apiKey.page.content[]| managed*` fields per `appconnect-auth` Step 5) — not
present in this snapshot. Confirm the actual field labels live before documenting them
here.

### Contacts → `contactTypes`, `contactPageUrl`, and related call-pop flags

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Supported contact types | repeatable Display/Value row pairs, "Add Contact type" | `contactTypes[]` |
| Contact page URL | text, tokens `{hostname}`, `{contactId}`, `{contactType}` | `contactPageUrl` |
| Enable fallback contact page URL for call-pop | checkbox | `enableFallbackContactPageUrl` |
| Enable contact search in activity logging | checkbox | `page.useContactSearch` |
| Disable contact cache | checkbox | contact-cache-disable flag |

Owned by `appconnect-contact-matching`. This snapshot had the fallback checkbox **off**,
so the paired `fallbackContactPageUrl` text field it should reveal when turned on wasn't
visible — confirm the revealed field's exact label live rather than guessing it matches
"Contact page URL" verbatim.

## Customize your adapter

### Custom settings → `platforms[x].settings[]`

Entry point only in this snapshot ("Add Setting Section" button, no rows configured).
Owned by `appconnect-settings-admin` — the per-item fields (type: `inputField` /
`boolean` / `option` / `warning`, `visibleToUsers`, etc.) that appear after clicking "Add
Setting Section" aren't captured here; confirm live when actually adding one.

### Admin settings → account-level / admin-only settings

Two subsections, both entry-point-only in this snapshot:

- **Account data sources** ("Add account data source") — this is very likely the guided
  form's entry point for the `accountDataKey`/`accountDataProperty` mechanism that
  `appconnect-custom-fields` and `appconnect-server-logging` both currently describe as
  *undocumented in the hosted manifest doc, only modeled off Bullhorn's source*. If
  confirmed live, this console section may be a much faster way to wire up an
  account-wide cached picklist than hand-writing the JSON from the Bullhorn example — but
  verify the field shape matches before relying on it as the primary path.
- **Standalone admin settings** ("Add standalone setting") — static dropdowns, text
  inputs, booleans, warning messages that don't depend on an account data source.

Owned by `appconnect-settings-admin`.

### Activity logging (general) → `logPageUrl`, `canOpenLogPage`, log format

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Log format | dropdown | log content-type/format setting |
| Enable extension number logging setting | checkbox | extension-number-logging flag |
| User can open activity page from the extension | checkbox | `canOpenLogPage` |
| Activity page URL | text, tokens `{hostname}`, `{logId}`, `{contactType}` | `logPageUrl` |

Owned by `appconnect-call-logging` (its Step 1 log-format decision and Step 2
`logPageUrl`/`canOpenLogPage` decision map directly to this section).

### Activity logging – call logging page / message logging page → `page.callLog.additionalFields[]` / `page.messageLog.additionalFields[]`

Both sections share the same "Page content" repeatable-item list ("Add item") and the
same nested field-editor UI. One item type was observed in full: **Selection Dropdown**.

| Console field (inside one field item) | Type | manifest field entry |
| --- | --- | --- |
| Item type | select | `field.type` (e.g. `"selection"`) |
| Field Key * | text | the field's `const`/key |
| Label * | text | `field.title`/label |
| Contact dependent | checkbox | `contactDependent` |
| Allow custom value | checkbox | `allowCustomValue` |
| Show if contact type | repeatable chip list | contact-type-conditional display list |
| Default setting ID | text, links to custom settings | `defaultSettingId` |
| Message / Voicemail / Fax setting ID | text | `messageSettingId` / `voicemailSettingId` / `faxSettingId` |

Owned by `appconnect-custom-fields` (this is exactly the `additionalFields[]` mechanism
that skill defines — the "Selection Dropdown" item type maps to its per-contact/
per-record association pattern). Both `appconnect-call-logging` and `appconnect-sms-logging`
should point here rather than re-describing it, since they only *read*
`additionalSubmission` values these fields produce — they don't own the field
definitions.

### Server-side logging → `serverSideLogging`

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Enable server-side logging | checkbox | `serverSideLogging` presence/`enabled` |
| Enable admin assigned owner | checkbox | likely `serverSideLogging.useAdminAssignedUserToken` or a related owner-attribution flag — **verify live**, the console's help text ("send call owner name/email... otherwise sends the call owner's token") doesn't map cleanly 1:1 onto `appconnect-server-logging`'s `useAdminAssignedUserToken`/`enableUserMapping` pair; don't assume which one this checkbox is before checking |
| Enable user mapping | checkbox | `serverSideLogging.enableUserMapping` |
| Page content (under "Customize the server-side logging settings page") | repeatable item list, "Add item" | `serverSideLogging.additionalFields[]` |

Owned by `appconnect-server-logging`. Given the naming ambiguity flagged above, treat the
"Enable admin assigned owner" checkbox's exact manifest mapping as unconfirmed until
checked against a live console session side-by-side with a known manifest — don't tell a
user it's definitely `useAdminAssignedUserToken` without that check.

## Support

### Resources → documentation/support links

| Console field | Type | manifest.json field |
| --- | --- | --- |
| Documentation URL | text | resources/documentation link |
| Release notes URL | text | resources/release-notes link |
| Review URL | text | resources/review link |
| Support URL | text | resources/support link |

Not currently owned by any skill in this set — mention to the user as available if they
ask, but no skill elicits these today.

## Global controls

- **Save** (master, bottom of page) — commits the whole screen.
- Per-row delete (trash icon) on repeatable list items; a small "x" clear icon on
  populated text fields.
- "Add ..." buttons scoped to each repeatable section (Platform URLs' URL lists, Contact
  types, Setting Section, account data source, standalone setting, page-content items).
