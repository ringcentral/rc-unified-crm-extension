# Shared progress-tracking procedure

Every `appconnect-*` build-pipeline skill ends this same way once its own work is
done and `PROGRESS.md` exists in the project root (it won't if the skill is being
run standalone, outside `appconnect-build-connector` — in that case the calling
skill's own "Progress tracking" section already told you to skip this file
entirely, so if you're reading this, `PROGRESS.md` exists).

1. Mark this skill's line `[x]` under `## Plan`.
2. Add a dated entry under `## Completed steps` summarizing what was actually built.
3. Find the next unchecked, non-skipped item in `## Plan` and set `## Status` to
   `Ready for '<that skill>' step` — or, if this was the last item, `Build complete`.
4. If something surfaced during this step that needs to be resolved before downstream
   skills can proceed safely (a missing field, an ambiguous API response, a manifest
   conflict), list it under `## Issues` instead, and set `## Status` to
   `Blocked after '<this skill>' step — see Issues below`.

Then stop: summarize what was built, show the updated `## Status` line, and ask the
user whether to proceed to the next step. Don't chain directly into the next skill —
pausing here keeps token/cost burn visible and under the user's control.
