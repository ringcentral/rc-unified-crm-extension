# Shared procedure: eliciting a templated manifest URL

Several manifest fields (`contactPageUrl`, `logPageUrl`, and similar per-record deep
links) follow the same elicitation pattern. Any skill that needs one should follow this
procedure rather than re-deriving it, substituting in its own target field name and
token set.

1. **Check whether the scheme is already known first.** Some CRMs publicly document a
   predictable deep-link format, or a sibling field already established the relevant
   convention (e.g. a `{hostname}` token decided during `appconnect-auth` or
   `appconnect-contact-matching`). If so, propose the templated URL directly from that
   known scheme and get a lightweight confirmation — skip the manual round-trip below.
2. **Otherwise, elicit a real example:**
   a. Ask the user to open (or create, if needed) the relevant record in the CRM's own
      web UI — a contact, a logged call/activity, or whatever record type this field
      points at.
   b. Ask them to copy and paste that URL back.
   c. Inspect the pasted URL and propose a templated version, substituting the parts
      that vary per record with tokens — commonly `{hostname}` (or the connector's
      actual dynamic-environment token) for a tenant-scoped subdomain, plus whichever
      record-identifying token applies (`{contactId}`, `{logId}`, etc.), and
      `{contactType}` if the CRM has multiple contact types.
3. **Confirm before writing, every time — this is a hard gate, not a formality to fold
   into a later recap.** Show the proposed template back to the user as its own turn and
   get an explicit confirmation before writing it to the manifest field. Stating the
   template as settled fact inside an end-of-session summary does not satisfy this gate.
4. **Reuse an established token convention rather than re-deriving it.** If a
   `{hostname}` (or equivalent) convention was already decided by an earlier skill in
   this build (recorded in that skill's `PROGRESS.md` note), use the same convention
   here instead of guessing independently — see `appconnect-auth`'s hostname-shape
   convention comment for where this typically gets decided first.

Copy-pasting a real URL and inferring the template from it is far less error-prone than
hand-writing one from memory, and directly avoids reproducing the
bare-subdomain-vs-fully-qualified-host bug class.
