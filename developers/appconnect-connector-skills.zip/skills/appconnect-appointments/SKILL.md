---
name: appconnect-appointments
description: >
  Implements appointment/calendar sync for an App Connect connector — listAppointments,
  createAppointment, updateAppointment, refreshAppointment, cancelAppointment, and
  confirmAppointment. Use when the user needs appointment scheduling or calendar sync
  between RingEX and the target CRM, e.g. "add appointment support to my connector",
  "sync calendar events with Foo CRM", "let users confirm or cancel appointments from
  the extension". Optional — only run this as part of a full build via
  appconnect-build-connector if the user selected appointment sync in scope.
---

# App Connect Appointments

Optional. Relevant for CRMs with a scheduling/calendar concept (common in verticals like
legal, financial services, and auto — think Redtail, VinSolutions-style connectors).

## Interfaces

All optional, but they form a coherent set — if implementing one, most connectors that
need appointments end up needing most of the set:

- **`listAppointments({ user, authHeader, ... })`** — fetch upcoming appointments to display in the extension.
- **`createAppointment({ user, authHeader, appointment, ... })`** — create a new appointment in the CRM.
- **`updateAppointment({ user, authHeader, appointmentId, appointment, ... })`** — modify an existing appointment.
- **`refreshAppointment({ user, authHeader, appointmentId, ... })`** — fetch the current state of a single appointment (e.g. after external changes in the CRM itself).
- **`cancelAppointment({ user, authHeader, appointmentId, ... })`** — cancel/delete an appointment.
- **`confirmAppointment({ user, authHeader, appointmentId, ... })`** — mark an appointment as confirmed.

## Notes

- Confirm exact field/response shapes against `docs/developers/interfaces/listAppointments.md`
  and the sibling `*Appointment.md` files before implementing — this cluster of
  interfaces has less cross-connector precedent in the bundled examples than auth or
  call logging, so lean on the docs rather than pattern-matching from another connector.
- If the target CRM's appointment model has states beyond confirmed/cancelled (e.g.
  rescheduled, no-show), check whether the manifest/interface contract has room for
  those or whether they need to be mapped down to the supported set — flag this to the
  user rather than silently dropping state.
- Time zone handling matters more here than almost anywhere else in the connector —
  double-check how the CRM represents appointment times (its own timezone vs UTC vs the
  user's local timezone from `getUserInfo`) before writing the create/update logic.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
