---
name: appconnect-auth
description: >
  Implements authentication for a standalone App Connect code connector — starting from
  the target CRM's OpenAPI spec (or, failing that, docs/direct questions) to determine
  OAuth vs static-credential auth, collecting the needed secrets into a git-ignored
  `.env`, wiring the manifest's auth block, implementing the auth interfaces
  (getAuthType, getOauthInfo, getBasicAuth, getUserInfo, refreshUserInfo, unAuthorize,
  authValidation, checkAndRefreshAccessToken, getManagedAuthOptions), and adding an auth
  test. Use when the user needs to wire up login/OAuth/API-key auth for a connector,
  says things like "set up auth for my connector", "add OAuth to Foo", "the CRM uses an
  API key, how do I collect that", or "make this admin-managed". Not for verifying the
  auth flow against a live client (that's appconnect-local-testing) — this skill only
  implements the interfaces. Usually run right after appconnect-setup as part of a full
  build via appconnect-build-connector.
---

# App Connect Auth

Auth is the one piece every other interface depends on — get the type and credential
flow right before moving on to contact matching or call logging.

**Scaffold context:** the `docs/developers/*.md` paths and sibling-connector examples
(`pipedrive`, `clio`, `insightly`, `redtail`, `bullhorn`, etc.) referenced throughout
this skill describe the App Connect monorepo — they don't exist in a project scaffolded
by `appconnect-setup` via `@app-connect/cli`. That standalone scaffold has no `docs/`
folder, no sibling connectors, and often no `manifest.json` yet either, despite what the
template's README implies. Don't go looking for any of these locally. Use the hosted
docs instead — `https://ringcentral.github.io/rc-unified-crm-extension/developers/manifest/`
and `https://ringcentral.github.io/rc-unified-crm-extension/developers/interfaces/` — and
if you need to see a real connector's code, fetch it from the monorepo on GitHub
(`ringcentral/rc-unified-crm-extension`, under `src/connectors/`) rather than searching
your own project.

## Step 1: Get the OpenAPI spec (first question)

Before asking the user anything about auth type, ask if they can provide the target
CRM/API's OpenAPI (or Swagger) spec — a file or a URL to one. Where practical, bundle
this together with Step 3's questions (auth type instinct, credential scope, URL/
environment shape) into a single structured question set rather than serial
back-and-forth — this cuts round trips and has worked well in practice. Only split them
apart if the spec's contents genuinely change what Step 3 needs to ask.

If provided, parse it for auth signals before asking the user anything further. Pull out
only the auth-relevant slice of the spec — don't ingest, summarize, or reason over the
whole document here:

- `components.securitySchemes` (OpenAPI 3) or `securityDefinitions` (Swagger 2) — look
  for `type: oauth2` (and which flow: `authorizationCode`, `clientCredentials`, etc.),
  `type: apiKey` (and `in: header`/`in: query` plus the exact key `name`), or
  `type: http` with `scheme: basic`/`bearer`.
- If `oauth2`: note the `authorizationUrl`, `tokenUrl`, and `scopes` — these map
  directly to the manifest's `auth.oauth` fields.
- If `apiKey`/`http basic`/`http bearer`: note the exact header name and scheme — this
  is what `getBasicAuth` will need to reconstruct later.

That's the full extent of what this skill needs from the spec. Everything else in
it — resource paths, request/response schemas for contacts, calls, appointments, etc. —
belongs to the skills that implement those features (contact-matching, call-logging,
appointments), and each of those pulls its own relevant paths from the spec
independently when it runs, rather than this skill front-loading them.

Summarize what the spec implies and confirm it with the user rather than silently
trusting the parse — specs are sometimes incomplete or describe more auth methods than
the API actually supports in practice.

If the user gives a URL to a spec but fetching it doesn't come back as parseable
text/JSON/YAML — e.g. it returns binary (`application/octet-stream`), an HTML wrapper
page, or a 404 — don't get stuck retrying the fetch or guessing from the URL shape.
Treat it exactly like "no spec available" and fall straight through to Step 2's
fallback.

## Step 2: No spec available

If the user can't provide a spec, say plainly that this makes the job harder, then:

1. Try searching online for the CRM's developer/API documentation as a substitute for
   the missing spec.
2. If that doesn't resolve it, ask the user directly: does the CRM/API use **OAuth** or
   **static credentials** (API key, username+password, tenant ID, etc.)?
3. Either way, still inspect whatever docs are available (spec, online docs, or
   whatever the user can paste in) to pin down the *exact* fields needed — which
   specific static credentials the login form must collect, and, for the manifest, the
   exact HTTP header name and scheme those credentials get sent with. Guessing this
   wrong means the manifest and the code disagree with the live API.

## Step 3: Confirm scope and shape

Once the auth type is known, confirm (don't assume) the following before moving on to
the manifest and interfaces — getting these wrong here means redoing manifest work
later.

### CRM URL / environment type

Ask how the CRM's base URL behaves across customers. App Connect's `environment` block
(see the hosted manifest doc,
`https://ringcentral.github.io/rc-unified-crm-extension/developers/manifest/`) supports
three shapes:

- **Fixed** — every customer hits the same URL (e.g. `https://api.example.com`). Maps
  to `environment.type: "fixed"`.
- **Selectable** — a small, known list of regional/deployment URLs the user picks from
  (e.g. US/EU/AU, or Clio's per-region hosts). Maps to `environment.type: "selectable"`.
- **Tenant-specific / per-tenant subdomain** — each customer has their own
  subdomain/instance that only they know (e.g. `https://acme.example.com`). Treat this
  as its own named pattern, not an edge case of Selectable — it's arguably *more common*
  than region-specific OAuth: Zendesk, Freshdesk, Zoho, and monday.com all work this way.
  Maps to `environment.type: "dynamic"` with the exact shape
  `environment: { type: 'dynamic', urlIdentifier, instructions }` — `urlIdentifier` is
  the placeholder token used in the base-URL template (e.g. `{tenant}`), and
  `instructions` is the user-facing copy explaining how to find their subdomain.

A spec with a single `servers` entry suggests Fixed; multiple region-specific base URLs
suggest Selectable; a `{tenant}`-style placeholder or docs mentioning "your subdomain"
suggest Tenant-specific — but confirm with the user rather than assuming from the spec
alone. See the hosted docs' regional-services page for how Selectable/Tenant-specific
flow into `getOauthInfo`'s `hostname` handling later.

### Scope of credential management (admin-managed auth)

Ask plainly: "Are there any credentials here that are shared across the organization
that an admin might want to manage centrally, instead of every user entering their
own?" Give the user a couple of concrete examples so they can recognize the pattern in
their own CRM rather than answering blind:

- A single OAuth client id/secret issued per company account rather than per user
  (ServiceTitan-style).
- A shared field — dealer ID, account number, tenant ID — that's the same for every
  user at a company rather than a personal API key (VinSolutions-style).

If every user brings fully individual credentials, admin-managed auth doesn't apply —
skip `managed`/`managedScope`/`managedFieldType` entirely in Step 5. If yes, capture
*which specific fields* are shared vs. individual now (this can apply to OAuth or to
API-key fields, at account or user scope) — Step 5 needs that exact mapping.

### Session-token exchange

Confirm whether a login call returns a short-lived session token that must be
validated/refreshed per request, on top of either OAuth or static credentials (e.g.
Bullhorn's `BhRestToken` pattern). This needs `authValidation` in addition to the base
auth functions.

## Step 4: Collect secrets into `.env`

As soon as concrete secrets are needed (OAuth client id/secret, or a static API
key/token used for local testing), create or update the project's `.env` file with
them as environment variables — never hardcode them in connector source. This is the
same `.env` appconnect-setup already git-ignored and stubbed out; this step is where
it actually gets filled in.

Don't just write empty/placeholder entries and leave a closing note asking the user to
"drop in your real credentials whenever ready" — that's a silent gap, easy to miss, and
gives the user no structured moment to actually provide the values. Instead, use the
`AskUserQuestion` tool, one question per secret (e.g. "What is your Zendesk OAuth
Client ID?" / "What is your Zendesk OAuth Client Secret?"), each with a short header
naming the field (e.g. `Client ID`) and options covering the realistic states the user
could be in — since the user may not have created the OAuth app yet:

- An option like "I have it — I'll paste it" whose description tells the user they can
  also just pick **Other** and type the value directly (the tool always offers Other
  as a free-text choice, which is how the actual secret value gets entered).
- An option like "Not created yet / skip for now" so the user isn't forced to type
  something before they're ready.

If the user skips, still write the `.env` key with an empty value so the variable name
is visible and ready, and call out explicitly (in prose, not buried in a checklist)
which keys still need filling before auth can be tested live. If the user provides a
value, write it straight into `.env`.

- Naming convention should match whatever this project's own `.env`/README already use
  (check what appconnect-setup stubbed out rather than inventing a new convention, since
  a standalone scaffold won't have sibling connectors to compare against) — historically
  this looks like `<CONNECTOR>_CLIENT_ID` / `<CONNECTOR>_CLIENT_SECRET` /
  `<CONNECTOR>_ACCESS_TOKEN_URI` / `<CONNECTOR>_REDIRECT_URI` for OAuth.
- Confirm `.env` is git-ignored (appconnect-setup should have already handled this —
  double check rather than assume) but present locally so auth can actually be
  exercised end-to-end during development.
- This local `.env` is separate from the deployed-secrets configuration for the App
  Connect server deployment itself (see the hosted deploy doc,
  `https://ringcentral.github.io/rc-unified-crm-extension/developers/deploy/`, if asked
  about that) — not this connector project's local dev secrets. Don't conflate the two
  or point the user at deploy docs for local dev setup.

## Step 5: Manifest auth block

First, check whether `manifest.json` exists at all — don't assume appconnect-setup
already created one. A project scaffolded via `@app-connect/cli` frequently doesn't ship
one despite the template's README implying it should be edited. If it's missing, create
a minimal skeleton first (`serverUrl`, `author`, and a `platforms.<connector name>`
stub) before adding the auth block below.

Set `auth.type` to `oauth` or `apiKey`. For OAuth, fill `auth.oauth` (URL, clientId,
redirectUri, scope) using the values pulled from the spec/`.env` in the steps above.
For API key, build `auth.apiKey.page.content[]` describing each login field. For
admin-managed fields, mark them `managed: true` with `managedScope: "account"` or
`"user"`, and `managedFieldType: "input"` or `"dynamic"` — dynamic managed fields need
`getManagedAuthOptions` (see appconnect-settings-admin, which owns that interface) to
supply the searchable choices. Verify current field names against the hosted manifest
doc, `https://ringcentral.github.io/rc-unified-crm-extension/developers/manifest/`,
before writing — auth manifest schema is one of the more detail-sensitive parts of the
platform.

**Manifest ↔ runtime field-name mapping (confirmed — don't re-derive from source):**
the manifest's OAuth block names the authorization endpoint field `authUrl`, but the
runtime `getOauthInfo()` (Step 6) needs `authorizationUri` and `accessTokenUri` —
related concepts, different names, and nothing flags the mismatch. Getting this wrong
breaks OAuth silently (no error thrown, the login flow just never completes). Cross-
check both the manifest and interfaces docs before wiring `getOauthInfo`.

Also set the manifest's `environment` block to match the URL type confirmed in Step 3
— `fixed`, `selectable`, or `dynamic` — per the hosted manifest doc's Environment
section. For `selectable`/`dynamic`, cross-check the hosted regional-services doc so the
manifest's environment config and `getOauthInfo`'s `hostname`-based branching (Step 6)
agree with each other.

### Pre-flight checklist — verify before handing off to appconnect-local-testing

The manifest gets cached twice — once in-memory server-side (loaded via `require()` at
dev-server startup) and once client-side in the extension's `chrome.storage.local`
(fetched once when the manifest URL is submitted in Developer Settings, never
auto-refetched). That means every manifest mistake discovered during
`appconnect-local-testing` costs a full loop — edit `manifest.json` → restart the dev
server → resubmit the manifest URL in the extension → retest — often 20+ minutes to even
observe the failure, let alone fix it. Get these right in this pass instead of
discovering them one at a time later:

- **Top-level `redirectUri` matches the nested one.** `AppConnectManifest.redirectUri`
  (top level) is a separate field from `platforms[x].auth.oauth.redirectUri` (nested).
  The extension's OAuth-completion polling (`sw.js`, `chrome.alarms.onAlarm`) only reads
  the top-level field. Miss it and the OAuth popup hangs on "Loading…" forever with no
  error anywhere. Always set both together.
- **Confirm the target CRM's OAuth app supports the standard Authorization Code grant
  without PKCE.** App Connect's OAuth flow doesn't support PKCE today (support is
  planned but not yet available). Every CRM's developer console labels this differently
  — Zendesk calls it "Confidential" vs "Public," others use different terms entirely —
  so don't hunt for a specific label. Instead, when the user is creating the OAuth app,
  confirm directly that it's set up for standard Authorization Code with a client secret
  (a "confidential client" in OAuth spec terms), and steer away from any option
  described as public-client, native-app, or PKCE-only. Getting this wrong produces a
  cryptic `invalid_request` with nothing pointing at the grant type as the cause — flag
  it *before* the OAuth app is created, not after the error shows up.
- **`{hostname}` templating for tenant-specific URL fields.** For `dynamic`/subdomain
  connectors (Step 3), a manifest URL field can use a literal `{hostname}` placeholder —
  e.g. `authUrl: "https://{hostname}.zendesk.com/oauth/authorizations/new"` — substituted
  at runtime with the tenant's subdomain. This is an established convention: the client
  already does `.replace('{hostname}', hostname)` for `contactPageUrl`, `logPageUrl`, and
  `callPopUrl` (`src/core/contact.js` lines 195/241/289, `src/core/log.js` line 134).
  **Open question, not yet resolved:** this substitution is not applied where the client
  builds the initial OAuth "authorize" popup URL (`src/popup.js` line 674, the generic
  non-Pipedrive/non-Bullhorn branch) — it uses `platform.auth.oauth.authUrl` verbatim. If
  you're building a `dynamic`-environment OAuth connector, confirm with engineering
  whether `{hostname}` is actually substituted into `authUrl` before relying on it —
  don't assume it works the same way it does for the contact/log/call-pop URLs.
- **`embedUrls` sanity check.** Not part of the `auth` block, but belongs in this same
  pass: `PlatformManifest.embedUrls: string[]` is the list of URL patterns where the
  extension's `content.js` renders the App Connect badge at all. Without a correct entry
  (or on a tab that doesn't match one), there's no way to even launch the auth flow — and
  the symptom looks identical to a broken OAuth redirect, wasting debugging time in the
  wrong place. Confirm it's set before moving on.

Treat this as a hard gate, not a "write it once, fix it as errors surface" step —
confirm all four points above before ever starting `appconnect-local-testing`.

## Step 6: Implement the interfaces

Required for every connector:

- `getAuthType()` → returns `'oauth'` or `'apiKey'`.
- `getOauthInfo({ hostname, isFromMCP })` (OAuth) or `getBasicAuth({ additionalInfo })`
  (API key) → returns the credentials/endpoints needed to authenticate.
- `getUserInfo({ authHeader, hostname, additionalInfo })` → calls the target API's
  "who am I" / current-user endpoint, returns
  `{ successful, platformUserInfo: { id, name, timezoneName, timezoneOffset, platformAdditionalInfo }, returnMessage? }`.
  Convention: suffix the returned `id` with `-<connectorname>` (e.g. `12345-zendesk`) so
  IDs can't collide across connectors sharing the same core.

**`getOauthInfo` idempotency (subdomain/tenant-scoped connectors):** this function is
called again on every token refresh, with its own previously-returned output as input —
not just once at initial login. For any `dynamic`-environment connector, trace explicitly
what value `getOauthInfo` returns as the hostname/tenant identifier, and confirm every
URL it builds re-derives the full domain from that returned value rather than assuming
the incoming `hostname` parameter is already fully-qualified. Test this by deliberately
forcing a token refresh, not just a fresh login — this bug class passes login testing and
only fails later, silently, inside an unrelated interface (it has shown up as a
`findContact` connection error).

As soon as `getOauthInfo` is implemented for a subdomain/tenant-scoped connector, write a
one-line convention comment at the top of the file stating exactly what shape the
hostname value takes, e.g.:

```javascript
// user.hostname is the BARE subdomain — any manifest field using {hostname} must
// append the full domain in the template string itself (e.g. "{hostname}.zendesk.com")
```

and record the same fact in `PROGRESS.md`. `{hostname}` has no single guaranteed meaning
across manifest fields — it's decided once here, but every manifest field that later uses
it (`authUrl`, `contactPageUrl`, `logPageUrl`, `callPopUrl`), often added by different
skills at different times, has to independently know the convention. Without this note,
later skills (contact-matching, call-logging) will re-derive or guess it — and risk
getting it wrong.

For API-key/basic-auth connectors specifically, the credential still has to be injected
into every outgoing HTTP request — this is the part that's easy to get subtly wrong.
`getBasicAuth` builds the encoded credential; every request handler then has to attach
it under the *exact* header name/scheme the API expects (from Step 1/2). Two real,
verified examples, from `src/connectors/insightly` and `src/connectors/redtail` in the
`rc-unified-crm-extension` monorepo on GitHub (not present in a standalone scaffold —
fetch them from GitHub if you want to see the live source):

```javascript
// src/connectors/insightly/index.ts
function getAuthType() { return 'apiKey'; }
function getBasicAuth({ apiKey }) {
  return Buffer.from(`${apiKey}:`).toString('base64');
}
// ...then on every outgoing request:
headers: { 'Authorization': authHeader }
```

```javascript
// src/connectors/redtail/index.ts
function getAuthType() { return 'apiKey'; }
function getBasicAuth({ apiKey }) {
  return Buffer.from(`${apiKey}`).toString('base64');
}
```

Note the encoding differs slightly between the two (trailing colon vs none) — this is
exactly the kind of detail that has to come from the target API's actual docs/spec, not
be copied blindly from either example. Confirm the header name (`Authorization` is
common but not universal), the scheme (`Basic ` prefix vs raw token vs custom scheme),
and the encoding before writing `getBasicAuth`.

Recommended:

- `unAuthorize({ user })` → revokes/clears tokens on logout.
- `refreshUserInfo({ user, authHeader })` → re-fetches user info after reconnect.

Only if the target API needs it:

- `authValidation({ user })` → validates a session-level token before each request; pair
  with retry-on-expiry logic (see Bullhorn's `BhRestToken` pattern in
  `src/connectors/bullhorn`, in the `rc-unified-crm-extension` monorepo on GitHub, for a
  real example).
- `checkAndRefreshAccessToken(oauthApp, user, tokenLockTimeout)` → for OAuth token
  refresh when the default refresh flow isn't sufficient.
- `getOverridingOAuthOption({ code, oauthInfo })` → only for non-standard OAuth flows.

## Step 7: Add an auth test

The standalone template (`packages/template`) doesn't ship an auth-specific automated
test today — only a generic server health-check test — so this is a new test to add,
not an existing pattern to copy. Add a Jest test (the repo already uses Jest 29)
alongside the connector code that:

- Mocks the target API's token endpoint (OAuth) or "who am I" endpoint (API key) with
  `nock` or an equivalent HTTP mock, rather than hitting the real API.
- Asserts `getAuthType()` returns the expected value.
- For OAuth: asserts `getOauthInfo` returns the right authorization/token URLs and that
  `checkAndRefreshAccessToken` (if implemented) refreshes correctly against a mocked
  expired-token response.
- For API key: asserts `getBasicAuth` encodes the credential correctly, and that
  `getUserInfo` sends the expected header/scheme and correctly maps a mocked response
  into `platformUserInfo`.

## Manual alternative: editing via the Developer Console

Pasting a whole new `manifest.json` into the console's **View source** JSON editor
(`appconnect-local-testing` Step 7) is fine for a brand-new connector, but not always
available or wanted for a later auth change on an already-registered one. The guided
form covers this skill's fields under two accordion sections — see
`../_shared/developer-console-guide.md` for the full field map, provenance, and caveats;
the relevant rows for this skill:

- **Authentication** section: Authentication type (OAuth/Static credentials), Admin-managed
  OAuth credentials checkbox, Auth URL, Client ID, Redirect URI, Custom state, Scope.
- **Platform URLs** section: CRM URL type (Fixed/Selectable/Tenant-specific → `environment.type`),
  CRM URL, Setup page instructions, Default embed URLs (`embedUrls[]` — the pre-flight
  checklist's sanity check above).

**Don't rely on the guided form alone for the top-level `redirectUri` pre-flight bullet
above.** The shared doc flags this as an open question: the console's single "Redirect
URI" field under Authentication maps to the *nested* `auth.oauth.redirectUri`, and it's
unconfirmed whether the guided form exposes (or auto-syncs) the separate top-level
`AppConnectManifest.redirectUri` the extension's OAuth-completion polling actually reads.
If a manifest already has both fields set correctly via a JSON paste, editing Auth URL/
Client ID/Scope through the guided form afterward is safe; but if the top-level
`redirectUri` still needs to be set for the first time, verify live whether the guided
form does it — falling back to **View source** for just that one field if it doesn't —
rather than assuming the single visible field covers both.

## Reference patterns

Look at `src/connectors/pipedrive` (OAuth) and `src/connectors/clio` (region-specific
OAuth, admin-managed option) for OAuth; `src/connectors/insightly` and
`src/connectors/redtail` for API-key/basic-auth with header injection; and
`src/connectors/bullhorn` (session token + `authValidation` + auto-refresh-on-401) for
concrete, working implementations to model against. These all live in the
`rc-unified-crm-extension` monorepo on GitHub — not in your standalone project — so
fetch them from there (e.g. via `github.com/ringcentral/rc-unified-crm-extension/tree/
master/src/connectors/<name>`) rather than searching your own repo for them. Don't
write auth logic from first principles if a close analog already exists.

## Handoff

Confirm `getUserInfo` returns a working user object (id, name, timezone) before moving
on — every downstream interface receives `user` and assumes this shape is correct.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
