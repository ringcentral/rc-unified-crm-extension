---
name: appconnect-build-connector
description: >
  Orchestrates end-to-end creation of a new RingCentral App Connect CRM connector as a
  standalone code connector, one step at a time, pausing for user confirmation between
  steps. Use whenever the user wants to build, scaffold, start, or create a new App
  Connect connector/integration/adapter for a CRM, help desk, or other business tool —
  e.g. "build an App Connect connector for Zendesk", "add a new CRM integration", "help
  me create a connector for our internal ticketing system". This is the entry point: it
  interviews the user once, then sequences the setup, auth, local-testing, and
  per-feature interface skills in the right order, finishing with appconnect-deploy and
  an optional final appconnect-code-review pass, and tracking progress in PROGRESS.md.
  Do not use this for tweaking one piece of an existing, already-scaffolded connector —
  route directly to the relevant feature skill instead (auth, local-testing,
  contact-matching, custom-fields, call-logging, sms-logging, appointments,
  settings-admin, server-logging, deploy, or code-review).
---

# App Connect Connector Builder (Orchestrator)

You are coordinating a multi-step build. Your job is to interview once, get a plan
confirmed, then hand off to the right feature skills **one at a time** — pausing for
explicit user confirmation between each — not to reimplement their knowledge yourself
and not to silently chain the whole build in one pass.

## Scope

This orchestrator only builds **standalone code connectors** — see appconnect-setup's
own disclaimer. If the user wants a declarative proxy connector (predictable REST
endpoints, no custom logic), point them at `docs/developers/proxy-connector.md` in the
App Connect repo instead of running this skill.

## Step 1: Check for a prior readiness assessment

Before interviewing, find out whether `appconnect-readiness` has already been run for
this CRM — its report should shape the interview instead of the interview re-deriving
things that skill already verified against the actual spec.

1. If the user hasn't already named the target CRM, ask for it now (this doubles as
   interview question 1 in Step 2 — don't ask twice).
2. Look for an existing report, in this order:
   - `docs/APPCONNECT_READINESS.md` — if a connector project for this CRM already
     exists (e.g. you're resuming a build), this is where `appconnect-readiness` copies
     its report per its own Step 10.
   - `appconnect-readiness-<crm-key>.md` in the current working directory — the default
     location when no project has been scaffolded yet.
3. **Found one?** Read it. Summarize its go/no-go verdict and its auth/scope
   recommendations (its Step 11 handoff summary is written for exactly this purpose),
   then use those recommendations to pre-fill Step 2's interview questions — still
   confirm each with the user rather than locking them in silently, since the report is
   an input to the interview, not a substitute for it.
4. **Found none?** Ask directly: "I don't see a readiness assessment for <CRM> yet —
   want to run `appconnect-readiness` first to check API compatibility before we
   scaffold anything, or skip straight to the build interview?"
   - If they want to run it first: invoke `appconnect-readiness`, then repeat step 2
     above once it finishes.
   - If they want to skip it: proceed to Step 2 as normal, and note in `PROGRESS.md`
     (once created in Step 4) that no readiness assessment was run — a future session
     reading the file should know this was a deliberate choice, not an oversight.

This check only costs a file lookup and a read of a short markdown report — trivial
next to the cost of discovering a fundamental API gap three feature skills into a
build.

## Step 2: Interview

Ask (skip anything already answered — including the CRM name from Step 1):

1. **Target CRM/system name** and its API docs or OpenAPI spec, if available.
2. **Auth type** the target API uses: OAuth 2.0, static API key/token, or something else
   (basic auth, session-token exchange like Bullhorn). If unsure, this is fine — the
   auth skill will help figure it out from the target API's spec/docs.
3. **Admin-managed auth?** Will one admin configure credentials once for a whole org, or
   does every end user authenticate individually?
4. **Which features are in scope beyond the required baseline?** Offer these as a
   checklist — required items aren't optional, the rest are:
   - Contact lookup by phone (**required** — `findContact`)
   - Call logging (**required** — `createCallLog`, `updateCallLog`)
     - Call disposition tracking (optional sub-feature of call logging —
       `upsertCallDisposition`). A "disposition" is a call outcome/category (e.g.
       "Interested," "No answer," "Follow up") that some CRMs track as its own record,
       separate from the log entry itself. Only offer this if the target CRM actually
       has that concept — not all CRMs support dispositions.
   - Custom fields on the call/message log (a note-type or activity-type dropdown) or
     linking a call/message to a related record like a matter/deal/ticket (optional —
     `appconnect-custom-fields`)
   - Search contacts by name (optional)
   - Create new contacts from unknown numbers (optional)
   - SMS/message logging (optional)
   - Appointment/calendar sync (optional)
   - Custom user/admin settings (optional)
   - Per-user license gating (optional — `appconnect-settings-admin`)
   - Server-side call logging for admins (optional — `appconnect-server-logging`; ask
     whether this is the toggle-only tier or the full tier with credential storage and
     RingEX-to-CRM user mapping)

## Step 3: Confirm the plan

Summarize as a short checklist before doing anything, e.g.:

```
Connector: Zendesk
Auth: OAuth 2.0, per-user (not admin-managed)
Scope: contact lookup, call logging, SMS logging
Skipping: appointments, custom settings, license gating, server-side logging, call disposition tracking
```

Get explicit confirmation before proceeding — this determines both which skills get
invoked and what gets seeded into `PROGRESS.md` in Step 4.

## Step 4: Run appconnect-setup, then seed PROGRESS.md

Invoke **appconnect-setup** first — it's the only skill that runs before the project
directory exists, so `PROGRESS.md` can't be created any earlier than this.

Once setup completes, create `PROGRESS.md` in the project root, seeded from the plan
confirmed in Step 2:

```markdown
# <CRM> Connector Build Progress

Last updated: <date>

## Status
Ready for 'appconnect-auth' step

## Readiness assessment
<path to appconnect-readiness report, or "Not run — skipped per user choice in Step 1">

## Plan
- [x] appconnect-setup
- [ ] appconnect-auth
- [ ] appconnect-local-testing
- [ ] appconnect-contact-matching
- [ ] appconnect-custom-fields (skipped — not in scope)
- [ ] appconnect-call-logging
- [ ] appconnect-sms-logging (skipped — not in scope)
- [ ] appconnect-appointments (skipped — not in scope)
- [ ] appconnect-settings-admin (skipped — not in scope)
- [ ] appconnect-server-logging (skipped — not in scope)
- [ ] appconnect-deploy

## Completed steps
### appconnect-setup — <date>
<one-line summary of what setup produced — project dir, key decisions>

## Issues
(none)
```

Mark scope items that weren't selected as `(skipped — not in scope)` rather than
omitting them — a future session (or the user) should be able to see the full plan, not
just what's left.

From this point on, **every subsequent skill maintains this file itself** (see each
skill's own "Progress tracking" section) — your job is to read the `## Status` line,
not to rewrite the file by hand.

## Step 5: Run one step at a time, gated on user confirmation

Invoke the remaining skills strictly in this order, skipping any whose scope wasn't
selected:

1. appconnect-auth
2. appconnect-local-testing — confirms auth actually works from a real App Connect
   client before any further interface work is built on top of it
3. appconnect-contact-matching
4. appconnect-custom-fields — only if a call/message-log custom field or a
   matter/deal/ticket association was selected in scope
5. appconnect-call-logging
6. appconnect-sms-logging — only if selected
7. appconnect-appointments — only if selected
8. appconnect-settings-admin — only if selected, or if dynamic managed-auth options
   were configured during appconnect-auth
9. appconnect-server-logging — only if selected. Independent of appconnect-settings-admin
   (it no longer covers server-side logging), but run it after appconnect-call-logging
   since server-side logging reuses `createCallLog`/`updateCallLog` rather than defining
   new logging logic of its own
10. appconnect-deploy — always last among required/selected build steps, regardless of
    which optional features were selected; deploy target is independent of interface
    scope

After each skill finishes, it will have updated `PROGRESS.md`'s `## Status` line and
`## Plan` checklist itself. Read the file, then:

- Summarize what the skill just built, in your own words.
- Surface the updated `## Status` line verbatim.
- If Status reads `Blocked after '<skill>' step — see Issues below`, stop and help
  resolve the listed issues before doing anything else — do not invoke the next skill.
- Otherwise, ask the user whether to proceed to the next step. **Only invoke the next
  skill after explicit confirmation** — never chain multiple skills' work in a single
  pass without pausing in between. This keeps token/cost burn visible and under the
  user's control, which matters more here than saving a round-trip.

Once `appconnect-deploy` reports `## Status: Build complete`, offer one more, purely
optional step: "Want me to run a code review pass over the generated connector —
security, performance, idiomatic patterns, and naming — before you call this done?" This
is `appconnect-code-review`. Unlike every step above, it's never assumed in scope from
the Step 2 interview and isn't pre-seeded as a required `## Plan` item — it's offered
fresh here because it only makes sense to run once there's finished code to review.

- If the user declines, leave `## Status` as `Build complete` and stop — do not add
  `appconnect-code-review` to `## Plan` at all if it's never going to run.
- If the user accepts, invoke `appconnect-code-review`. It will add its own `## Plan`
  line and update `## Status`/`## Completed steps`/`## Issues` per its own "Progress
  tracking" section — same pattern as every other skill in this pipeline.
- This offer can also be accepted later, in a separate session — resuming per Step 6
  below still finds `## Status: Build complete` and can re-offer it then.

## Step 6: Resuming across sessions

If this build spans multiple conversations, read `PROGRESS.md` before doing anything
else — its `## Status` line says exactly which skill to run next (or what's blocking),
and its `## Readiness assessment` line says whether Step 1 was already handled, so
there's no need to re-run the Step 1 check or the Step 2 interview.

## Guardrails

- Never invoke more than one sub-skill per user turn without an explicit go-ahead — see
  Step 5. This applies even if the user says something broad like "just build the whole
  thing" up front: still pause and report between steps, and confirm at each pause
  rather than treating the initial ask as a blanket approval for every step.
- Never assume the target project is the App Connect extension's own repo
  (`rc-unified-crm-extension`) — this orchestrator builds standalone projects only (see
  Scope above).
- Secrets always go in environment variables, never hardcoded — the auth skill handles this.
- If the target API's docs are ambiguous or missing, say so rather than guessing at
  endpoints — a wrong guess baked into generated code is worse than pausing to ask.
