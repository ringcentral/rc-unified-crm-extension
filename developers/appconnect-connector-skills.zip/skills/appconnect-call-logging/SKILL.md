---
name: appconnect-call-logging
description: >
  Implements call logging for an App Connect connector — createCallLog and
  updateCallLog (required), plus getCallLog, getLogFormatType, and
  upsertCallDisposition (optional) — plus log body format (plain text/HTML/Markdown)
  and the call-log deep-link URL. Use when the user needs calls written to the CRM as
  activities/notes/time entries, needs logs updated with recordings/transcripts after
  the fact, needs disposition tracking, or asks about the log's rich-text format or
  deep-link URL, e.g. "implement call logging", "log calls as activities in Foo CRM",
  "add recording links after the call ends". Also covers ticketing/case systems with no
  native call object (Zendesk, Freshdesk, Jira Service Management, ServiceNow) via an
  append-only, comment-on-ticket pattern. For custom fields or linking a call to a
  matter/deal/ticket, run appconnect-custom-fields first — this only reads what that one
  defines. Usually runs after appconnect-contact-matching and appconnect-custom-fields
  via appconnect-build-connector.
---

# App Connect Call Logging

Required for every connector — this is the core value proposition of App Connect
(calls show up in the CRM automatically).

## The flow

A call arrives → the user or an auto-log rule triggers logging → core refreshes auth →
core composes the log body (if the connector declares a text/HTML/Markdown format via
`getLogFormatType`) → `createCallLog` is invoked → core stores a mapping from the
RingCentral call to the returned CRM log ID. Later, when recordings, AI notes, or a
finalized duration/outcome arrive, core calls `getCallLog` (to read the current CRM
state and avoid clobbering the user's own edits) followed by `updateCallLog`. See
`docs/developers/logging-calls.md` in the App Connect repo for the full sequence
including server-side logging (`isFromSSCL`) nuances.

**Custom fields and record associations are handled by `appconnect-custom-fields`, not
here.** If the target CRM needs a note-type/activity-type dropdown on the call-logging
page, or calls need to link to a matter/deal/ticket, run that skill first — it defines
the `page.callLog.additionalFields[]` entries and the `contactDependent`/
`accountDataKey` wiring. This skill's `createCallLog`/`updateCallLog` below just read
whatever ends up in `additionalSubmission`, keyed by the `const` that skill chose. If
`appconnect-custom-fields` hasn't run yet and the user asks for one of those things here,
say so and hand off rather than improvising the manifest field inline.

**If the field already exists but needs a new option, that's this skill's call — not a
full hand-off.** A common case: `appconnect-contact-matching` already built a
record-association picker (e.g. a `ticketId` field) for linking calls to an existing
record, and this skill's design (see Step 0) needs a "Create ticket..." sentinel option
added to that same picker so a call can create a new target instead of only logging to
an existing one. Propose the new option and its `const` to the user, confirm, and add it
to the existing field's `options[]` (or wherever `appconnect-custom-fields` sourced the
list from) rather than improvising a whole new field or bouncing back to that skill.
Reserve the actual hand-off for when the field doesn't exist at all yet.

Before writing any code, work through Steps 0–2 below with the user — they determine
whether a real loggable CRM entity exists at all, and if so, the log body format and
deep-link URL that the interfaces in the last section actually rely on.

## Step 0: Does the CRM have a native call/activity/log object?

Ask this before Step 1 — it changes what "create a log" even means for the rest of this
skill.

Most connectors log into a discrete CRM entity (an "activity," "note," "time entry,"
"communication") that has its own ID and supports a real update-in-place PATCH.
Ticketing/case-management CRMs (Zendesk, Freshdesk, Jira Service Management, ServiceNow,
and similar) typically don't — there's no first-class "call log" object at all, only
tickets/cases with a comment/note thread on them. If the target CRM is one of these, work
through this decision tree instead of assuming a loggable entity exists:

1. **What does a logged call become?** Usually the least-bad fit is a private/internal
   comment on a ticket/case — confirm this is actually possible via the API (most
   ticketing APIs support an internal-only comment/note flag distinct from a
   customer-visible reply) rather than assuming it.
2. **Does the user always pick a target, or can one be created inline?** If a
   record-association picker already exists (built by `appconnect-contact-matching` or
   `appconnect-custom-fields`, e.g. `ticketId`), decide whether call-logging also needs a
   "create a new ticket for this call" option in that same picker — commonly done via a
   sentinel option (e.g. `const: "__create_new__"`, `title: "Create ticket..."`) that
   `createCallLog` checks for and branches on before falling back to the chosen existing
   ID. See the boundary note above for who adds that option to the manifest.
3. **Is the resulting entry editable at all?** Many ticketing APIs make comments
   immutable once posted (no PATCH). If so, read "The append-only logging pattern" below
   before implementing `updateCallLog`/`getCallLog` — the meaning of "update" and "read
   for merge" both change.

If the CRM does have a real loggable entity with a working PATCH, skip straight to Step 1
— the interfaces below work as written.

### The append-only logging pattern

Name this explicitly once discovered, since it changes what two interfaces mean:

- **`updateCallLog` can't patch the original entry.** Post a new comment carrying the
  updated info (finalized duration, recording link, AI summary) instead of trying to edit
  the first one. Make the follow-up obviously distinguishable in the log body (e.g. a
  "Call update:" prefix or a repeated call identifier) so a CRM user reading the thread
  can tell it's a follow-up rather than an unrelated comment.
- **`getCallLog`'s purpose flips.** In the normal (patchable) case, `getCallLog` exists so
  `updateCallLog` can merge without clobbering CRM-user edits. In the append-only case
  there's nothing to merge into — `getCallLog` (and the `existingCallLogDetails` it feeds
  into `updateCallLog`) is only useful for *finding the most recent entry to display or
  reference*, not as a merge target. Don't force merge logic that doesn't apply.
- This pattern is likely common across ticketing-style CRMs generally, not just Zendesk
  (Freshdesk, Jira Service Management, and ServiceNow are plausible matches) — expect to
  recognize it again rather than rediscovering it from scratch.

## Step 1: Log body format — plain text, HTML, or Markdown?

Ask directly: does the CRM's note/activity field render HTML or Markdown, or does it
need plain text? A quick way to check without guessing: look at whether an existing
note/activity in the CRM's own web UI supports rich text (bold, bullet lists, links) —
if it does, confirm which markup its API actually expects for that formatting (HTML tags
vs. Markdown syntax aren't interchangeable, and CRMs vary).

Implement `getLogFormatType()` returning one of `LOG_DETAILS_FORMAT_TYPE.PLAIN_TEXT |
HTML | MARKDOWN` (confirm the exact constant import path against the scaffolded
template — a standalone project may expose `@app-connect/core/lib/constants`
differently than the monorepo does). Returning one of these three lets core assemble
`composedLogDetails` (call details, agent notes, AI summary — consistently formatted)
instead of the connector hand-building the string. Only skip this and compose the body
manually inside `createCallLog`/`updateCallLog` if the target format genuinely isn't one
of the three core supports.

## Step 2: Call-log deep link (`logPageUrl`)

A user who just logged a call will want to click through and see it in the CRM. Elicit
this using the shared procedure in `../_shared/url-template-elicitation.md`, targeting
the manifest's `logPageUrl` field with tokens `{hostname}` (or the connector's actual
dynamic-environment token), `{logId}`, and `{contactType}` (if the CRM has multiple
contact types) — e.g. Clio's shipped
`https://{hostname}/nc/#/contacts/{contactId}/communications` or Pipedrive's
`https://{hostname}/activities/{logId}`. The "already known" fast path applies often
here: many ticketing/case CRMs publicly document a predictable deep-link format (e.g.
Zendesk's `/agent/tickets/{id}`), and a subdomain/tenant-scoped connector may have
already established the `{hostname}` convention during `appconnect-contact-matching`'s
`contactPageUrl` step or during `appconnect-auth` (bare subdomain vs. fully-qualified
host — check that skill's PROGRESS.md note) — reuse either rather than re-deriving it.

The manifest's `canOpenLogPage: true` opens `logPageUrl` for a logged call; `false` falls
back to `contactPageUrl` instead — confirm with the user which behavior is wanted.

There is no separate `callPopUrl` manifest property despite it being referenced in some
older internal notes — the shipped schema and every current connector's manifest only
define `contactPageUrl` and `logPageUrl`. Use `logPageUrl` here.

## Interfaces

**`createCallLog({ user, contactInfo, authHeader, callLog, note, additionalSubmission, aiNote, transcript, recordingLink, voicemailLink, ringSenseTranscript, ringSenseSummary, ringSenseBulletedSummary, ringSenseLink, composedLogDetails, hashedAccountId, isFromSSCL, proxyConfig })` — required**
Create the CRM activity/note/time-entry for the call. Returns `{ logId, returnMessage?,
extraDataTracking? }` — a missing `logId` is treated as failure. Read any custom fields
defined by `appconnect-custom-fields` out of `additionalSubmission`, keyed by the
manifest field's `const` (e.g. `additionalSubmission.matters`,
`additionalSubmission.noteActions`).

**`updateCallLog({ user, existingCallLog, existingCallLogDetails, authHeader, recordingLink, recordingDownloadLink, voicemailLink, subject, note, startTime, duration, result, aiNote, transcript, legs, ringSenseTranscript, ringSenseSummary, ringSenseBulletedSummary, ringSenseLink, additionalSubmission, composedLogDetails, hashedAccountId, isFromSSCL, proxyConfig })` — required**
Update a previously-created log with new data (recording link, finalized AI notes,
user-edited fields). `existingCallLog.thirdPartyLogId` is the CRM's own log ID — no need
to return it again. Use `existingCallLogDetails` (populated from `getCallLog`'s
`fullLogResponse`, if implemented) to merge rather than overwrite fields the CRM user
may have edited directly.

**`getCallLog({ user, telephonySessionId, callLogId, contactId, authHeader, proxyConfig })` — recommended**
Fetch the current state of a previously-created log. Returns
`{ callLogInfo: { subject, note, fullBody, fullLogResponse, contactName?, dispositions? }, returnMessage?, extraDataTracking? }`.
`fullLogResponse` is passed back into `updateCallLog` as `existingCallLogDetails` — this
is what makes merge-not-clobber possible.

**`getLogFormatType(platform, proxyConfig)` — recommended**
Covered in Step 1. Returns a `LOG_DETAILS_FORMAT_TYPE` constant, or omit/return something
else to compose the body manually.

**`upsertCallDisposition({ user, existingCallLog, authHeader, dispositions, proxyConfig })` — optional**
Returns `{ logId, returnMessage?, extraDataTracking? }` (truthy `logId` = success). Only
one shipped connector implements this today — Clio — and its actual behavior is
narrower than the interface name suggests: it re-applies the record-association field
(`dispositions.matters`) onto the already-created log via a PATCH, rather than writing a
separate call-outcome object. Before implementing, confirm directly with the user (and
against the current hosted `interfaces/upsertCallDisposition.md` page — the doc's stated
intent should take precedence over this one shipped example if they disagree) whether
"disposition" here means (a) letting the user change which matter/deal/ticket a call is
linked to after the fact, or (b) a genuine outcome/status code (e.g. "Interested," "No
answer," "Follow up") tracked as its own field or record. Only implement it if the target
CRM's API actually supports one of these; otherwise skip it and rely on
`createCallLog`/`updateCallLog` alone.

**Skipping this now is not necessarily the end of the thread.** A genuine outcome/status
concept commonly resurfaces later under a different name — e.g. a request for a "ticket
status" or "call outcome" setting on the log form is often the same thing the user
already declined to build here. When it resurfaces, route it to `appconnect-custom-fields`
(as a dropdown/manifest `additionalField`) rather than treating it as an unrelated new
requirement — note the earlier disposition conversation so the connection isn't lost.

## Manual alternative: editing via the Developer Console

For an update to an already-registered connector, the guided form covers Steps 1–2's
manifest fields in one place — see `../_shared/developer-console-guide.md` for the full
field map, provenance, and caveats:

- **Activity logging (general)** section: Log format (`getLogFormatType`'s manifest-side
  counterpart), Enable extension number logging setting, "User can open activity page
  from the extension" (`canOpenLogPage`), Activity page URL (`logPageUrl`).

Custom fields on the call-logging page itself (`page.callLog.additionalFields[]`) are a
different console section, owned by `appconnect-custom-fields` — see that skill's own
Developer Console section rather than looking for them here.

## Reference patterns

- `src/connectors/clio`: reads `additionalSubmission.matters` in `createCallLog` to set
  `data.matter.id` on the communication, and is the one shipped `upsertCallDisposition`
  example (PATCHes the same matter association back onto an existing log).
- `src/connectors/pipedrive`: reads `additionalSubmission.deals`/`.leads` in
  `createCallLog` for record association.
- See `appconnect-custom-fields`'s Reference patterns for how those `additionalSubmission`
  keys get defined in the manifest in the first place (Bullhorn's account-wide
  `noteActions` cache, Clio's `matters`, Pipedrive's `resolveActivityType()`).

## Standalone runs: files to read first

If this skill is being run outside `appconnect-build-connector` (no `PROGRESS.md` to
read for state), don't reach for a full-repo exploration subagent by default — the
`@app-connect/cli` scaffold layout is standard enough to go directly to these files:

- The five interface files this skill touches: `createCallLog.ts`, `updateCallLog.ts`,
  `getCallLog.ts`, `getLogFormatType.ts`, `upsertCallDisposition.ts` (exact paths per the
  scaffolded template's connector structure).
- `manifest.json` — for the current `page.callLog` config, `canOpenLogPage`, and any
  fields `appconnect-custom-fields` already defined.
- The connector's main wiring/index file — for how these interfaces get registered.
- `findContact.ts` — for whatever `contactDependent`/`additionalInfo` shape
  `appconnect-contact-matching` already established, since call-logging reads it.

If a subagent is used anyway (e.g. because the scaffold has drifted from the standard
layout), scope its prompt to just these files rather than the whole auth/contact-matching
stack — broad exploration here reads as wasted effort even when it technically isn't.

## Notes

- Don't invent request/response field names from memory — confirm current names against
  `docs/developers/interfaces/createCallLog.md`, `updateCallLog.md`, `getCallLog.md`, and
  `getLogFormatType.md` before implementing, and cross-check
  `upsertCallDisposition.md` if disposition tracking is in scope. `accountDataKey` /
  `accountDataProperty` are the one exception — they're real (see Bullhorn) but not in
  the hosted docs, so go to source instead.
- **Known cross-skill gap:** logging to a custom field (e.g. `additionalSubmission`
  values from `appconnect-custom-fields`) assumes that field already exists in the target
  CRM account. None of the `appconnect-*` skills currently provision a missing custom
  field (e.g. via a Ticket Fields API) — they only map to fields assumed to pre-exist.
  This surfaces here when logging to a fresh/unconfigured account fails, but the fix
  belongs in `appconnect-custom-fields` and/or `appconnect-settings-admin`, not here.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete.

If `PROGRESS.md` doesn't exist (this skill is being run standalone, outside
appconnect-build-connector), don't skip persistence outright — offer to create or append
to a lightweight `TODO.md`/notes file instead, recording the real design decisions made
in this run (e.g. which record type calls log into, the create-vs-existing-target
picker/sentinel, append-only vs. patchable updates, whether disposition was skipped and
why). Without this, decisions made ad hoc in a standalone run only live in chat until
someone asks for them to be written down later.
