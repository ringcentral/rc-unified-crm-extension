---
name: appconnect-code-review
description: >
  Performs a focused code review of a scaffolded App Connect connector's generated
  source — flagging security vulnerabilities, performance/optimization opportunities,
  non-idiomatic patterns relative to the App Connect reference implementations, and
  poor or inconsistent function/variable naming. Use when the user wants a review,
  audit, or sanity-check of connector code, e.g. "review the connector code before we
  ship", "check this for security issues", "does this code look idiomatic", "clean up
  naming before deploy", "audit my connector". Optional — never runs automatically;
  appconnect-build-connector offers it once, as the final optional step after
  appconnect-deploy finishes. Can also run standalone against any already-scaffolded
  connector project, independent of the build pipeline. Produces a findings report
  first and only edits files after the user confirms which findings to fix — it never
  silently rewrites code.
---

# App Connect Code Review

You are doing a focused, practical code review of a generated connector — not a
line-by-line style nitpick session. Read first, report findings grouped by category and
severity, then only touch code the user asks you to fix.

## Scope

This skill reviews the **generated connector project only** (e.g.
`appconnect-<crm>-connector/`) — never `rc-unified-crm-extension` itself, per this
plugin's standing guardrail. If the App Connect extension repo is open in the workspace,
this skill may *read* its reference connectors
(`src/connectors/{pipedrive,clio,bullhorn}`) as an idiom baseline, but that repo is never
a review target and is never edited.

It is read-first: Steps 1–3 only inspect code and produce a report. Step 4 offers to
apply fixes, gated on the user picking which findings to act on — the same confirmation
gate `appconnect-deploy` uses before deleting scaffolding.

## Step 1: Identify what to review

Focus on connector-authored code, not vendored dependencies or template boilerplate that
was never touched:

- Everything under `src/` — auth interfaces, `findContact`/`findContactWithName`/
  `createContact`, call/message logging, appointments, settings/license interfaces,
  server-side logging, and the manifest.
- Deploy scaffolding actually kept after `appconnect-deploy` ran (Heroku/Azure/Lambda
  files), if present — these are hand-authored or hand-trimmed, not pure template output.
- Skip `node_modules/`, build output (`dist/`, `lib/`), and any file the user confirms
  was never modified from the `@app-connect/cli` template default.

If `PROGRESS.md` exists, read it first — its `## Completed steps` log says which
features were actually built, so the review can be scoped to real surface area instead
of guessing from a directory listing.

## Step 2: Review categories

Work through each category below. Not every category will surface findings in every
connector — say so rather than padding the report with non-issues.

### Security

- Hardcoded secrets, API keys, or tokens instead of environment variables — this
  violates the plugin's own standing guardrail (secrets always go in env vars, set up by
  `appconnect-auth`). Flag every instance, not just the first.
- Missing or weak input validation on data coming from the CRM's API or from webhook/
  callback payloads before it's used in a URL, log line, or downstream API call.
- Secrets, tokens, or full request/response bodies written to logs or error messages —
  common in a `catch` block that logs the whole error object from an HTTP client.
- Unvalidated redirect or URL construction from user- or CRM-supplied input (relevant
  around `contactPageUrl`, `fallbackContactPageUrl`, and OAuth redirect handling).
- Overly broad OAuth scopes requested relative to what the implemented interfaces
  actually use.
- `checkAndRefreshAccessToken` / token-refresh logic that doesn't handle a failed
  refresh safely (e.g. swallowing the error and proceeding with a stale/undefined
  token).

### Performance / optimization

- Redundant API calls — e.g. re-fetching a contact or account record already available
  from an earlier call in the same request, or looked up in a loop instead of batched.
- Missing pagination handling where the target CRM's API paginates results (a
  `findContactWithName` or `getUserList` that silently only returns page one).
- Sequential `await`s for independent network calls that could run concurrently via
  `Promise.all`.
- Unbounded loops over API results without a cap or cursor limit.
- Synchronous/blocking work (heavy JSON transforms, crypto, file I/O) on the request
  path that could be deferred or streamed.

### Idiomatic patterns

- Compare against the reference connectors
  (`src/connectors/{pipedrive,clio,bullhorn}` in the App Connect repo) when available:
  error-handling shape, how interfaces return `null`/`undefined` vs. throw, how the
  manifest's `platform` config is referenced from code, and how HTTP clients are
  constructed and reused.
- Interface methods that don't match the shape App Connect expects (wrong return type,
  missing a required field the docs specify, sync where the interface must be async).
- Copy-pasted blocks across interfaces (e.g. near-identical HTTP-error handling in both
  `createCallLog` and `createMessageLog`) that should be a shared helper.
- Magic strings/numbers that should be named constants, especially CRM-specific field
  IDs, custom-field keys, or status codes.

### Naming

- Function and variable names that don't match the App Connect interface contract's own
  naming (e.g. an implementation of `findContact` internally calling something named
  `lookupUser` — fine internally, but flag if it creates confusion with no docstring/
  comment tying the two together).
- Inconsistent naming for the same concept across files (e.g. `crmContact` in one file,
  `contactRecord` in another, `remoteContact` in a third, all meaning the same thing).
- Abbreviations or single-letter variables outside of trivial loop counters.
- Boolean variables/params that don't read as booleans (`status` instead of
  `isActive`/`hasError`).

## Step 3: Produce a findings report

Present findings grouped by the four categories above, each entry with: file and line
(or function name if line numbers would drift), a one-line description of the issue, why
it matters, and a concrete suggested fix. Tag each finding's severity:

- **High** — security vulnerabilities, and correctness bugs that would break the
  connector in production.
- **Medium** — performance issues, non-idiomatic patterns likely to cause bugs later.
- **Low** — naming/consistency/style issues with no functional impact.

Lead the report with a one-line summary count per severity (e.g. "2 high, 3 medium, 6
low"). Don't inflate the report — a clean file deserves a short "no findings" note, not
manufactured nitpicks.

## Step 4: Offer to apply fixes (gated)

Ask the user which findings to act on — by severity tier ("fix all high and medium"), by
category, or individually. Only edit files for findings the user confirms. For each fix
applied, make the smallest change that resolves the finding rather than an opportunistic
rewrite of surrounding code the user didn't ask about.

If a finding requires a judgment call with more than one reasonable fix (e.g. how to
batch a paginated call), present the options briefly instead of silently picking one.

## Progress tracking

If `PROGRESS.md` exists in the project root, update it once this step is complete,
following the shared mechanics in `../_shared/progress-tracking.md`, with these
differences specific to this skill:

1. The completed-steps entry should record the severity counts from Step 3 and a
   one-line note on what was fixed vs. left open.
2. This skill runs after `appconnect-deploy`, which is otherwise the last item in
   `## Plan` — if this is the first time code review has run, add
   `- [ ] appconnect-code-review (optional)` to `## Plan` before checking it off, since
   the template seeded in `appconnect-build-connector` doesn't include it by default.
3. Set `## Status` to `Build complete` (or leave it as `Build complete` if
   `appconnect-deploy` already set it) — code review doesn't unblock a next build step,
   it's a final quality pass.
4. If high-severity findings were left unfixed by user choice, note them under
   `## Issues` so a future session sees them rather than assuming the connector is
   clean.

Then stop and summarize, same as every other skill in this plugin. If `PROGRESS.md`
doesn't exist (this skill is being run standalone), skip this section entirely.
