---
name: appconnect-contact-matching
description: >
  Implements contact lookup for an App Connect connector — findContact (required),
  plus optional findContactWithName and createContact — including the
  contact-dependent additional-info pattern used to link calls to related records
  (deals, matters, opportunities), and the call-pop URLs (contactPageUrl, and
  fallbackContactPageUrl/enableFallbackContactPageUrl for no-match). Use when the user
  needs phone-to-contact matching, contact search by name, contact creation from an
  unknown number, or call-pop to open a fixed CRM page when no match is found, e.g.
  "implement findContact for my connector", "how do I look up contacts by phone",
  "link calls to the deal a contact belongs to", "what should call-pop do with no
  matching contact". Not for custom-field dropdowns or record-linking UI
  (appconnect-custom-fields) — this only supplies the additional-info data those read.
  Usually runs after appconnect-auth and appconnect-local-testing, once login is
  confirmed working from a real client, via appconnect-build-connector.
---

# App Connect Contact Matching

This is the interface that powers call pop and the phone-number → contact link that
every other logging interface depends on. Required for every connector.

## Determine whether the target API needs exact phone-number formatting

Resolve this **before** finalizing `findContact` — it changes the function's shape, and
guessing wrong here is one of the most common App Connect integration bugs (see
`docs/troubleshooting/contact-not-found.md` in the App Connect repo).

**The problem:** RingCentral always sends phone numbers to `findContact` in E.164 format
(`+15105551234`). Some CRM search APIs only match the exact string stored on the
record, so if a contact's number is stored as `(510) 555-1234` or `510.555.1234`, an
E.164 query returns nothing even though the contact exists. `docs/users/phone-number-formats.md`
lists Clio, Insightly, and NetSuite as CRMs known to exhibit this.

App Connect already has a mechanism for this, and it costs the connector nothing to
wire up: a core-level "advanced" user setting (under the client's Contacts settings)
lets a user list comma-separated alternate formats using `#`/`*` as digit placeholders
(e.g. `(###) ###-####`). Core passes whatever the user configured into **every**
`findContact` call as `overridingFormat` automatically — there's no manifest field to
add for this. The connector's job is just to decide whether it needs to use that
parameter, and if so, implement the search loop.

### Ask before probing, then confirm empirically if needed

Ask the user directly, before implementation, whether they already know how the target
CRM's phone search behaves: "Does [CRM]'s contact search match only the exact stored
format, or does it normalize/fuzzy-match phone numbers?" Many CRMs (Zendesk included) do
strict exact-match phone search — if the user or the CRM's docs already know this, go
straight to the matching pattern below and skip the probe entirely.

If nobody's sure, confirm against the real API once `appconnect-auth` produces a working
`authHeader`/`getUserInfo`, before writing real `findContact` logic. **This needs a live
connection to the target CRM**, typically outside this agent's own sandbox — say upfront
that the user will need to run the actual calls themselves (via `appconnect-local-testing`
or a direct API call), and use best-documented behavior in the meantime rather than
blocking on it.

The probe itself: create a test contact via `createContact` (build a minimal version now
if it doesn't exist yet — this doubles as an early smoke test of that callback) using a
phone number in a format you fully control, e.g. E.164 (`+15105551234`). Then query the
search endpoint with several representations of that number — the exact string, E.164,
digits-only, and a common local format like `(510) 555-1234`. If only the exact string
matches, the API is strict exact-match and needs the alternate-format loop below; if a
differently-formatted query also matches, it normalizes internally and the loop isn't
needed. Clean up (delete/archive) the test contact afterward, or tell the user one is
left behind if that's not possible.

Report the result to the user before proceeding — it determines which of the two
patterns below `findContact` should follow.

### If the API requires exact matching

Follow the pattern used by `src/connectors/clio`, `src/connectors/insightly`, and
`src/connectors/netsuite` in the App Connect repo (all three are listed as known-affected
in `docs/users/phone-number-formats.md`):

1. Always include the raw E.164 number as one query candidate.
2. If `overridingFormat` is a non-empty comma-separated string, for each format: strip
   the E.164 number's country code to get its significant digits, then substitute those
   digits one-by-one into each `#`/`*` placeholder in the format string, left to right.
3. Query the CRM once per candidate and merge/dedupe results by contact ID — don't stop
   at the first hit. Clio's implementation queries every candidate rather than stopping
   early, so a contact stored in an unexpected format still turns up.

```javascript
// modeled on src/connectors/clio/index.ts and src/connectors/insightly/index.ts
const { parsePhoneNumber } = require('awesome-phonenumber');

const numberToQueryArray = [phoneNumber.replace(' ', '+')]; // raw E.164 first
if (overridingFormat) {
  for (const format of overridingFormat.split(',')) {
    const parsed = parsePhoneNumber(phoneNumber.replace(' ', '+'));
    if (parsed.valid) {
      let formatted = format;
      for (const digit of parsed.number.significant) {
        formatted = formatted.replace(/[*#]/, digit);
      }
      numberToQueryArray.push(formatted);
    }
  }
}
// query the CRM once per candidate in numberToQueryArray, merging/deduping matches by id
```

If probing confirms the target CRM is affected, ask the user whether they'd like it
added to `docs/users/phone-number-formats.md`'s "CRMs known to exhibit this problem"
list in the App Connect repo — that's an allowed `docs/*` edit, but confirm first since
it's a shared doc beyond this connector's own project.

### If the API normalizes/fuzzy-matches

Implement a single best-effort query — strip formatting and search on digits (or pass
the E.164 number directly if the API accepts it) — and still accept `overridingFormat`
in the function signature for interface-contract compliance, even though the loop
degenerates to one iteration when it's empty. `src/connectors/netsuite` is a good
example of this hybrid: when `overridingFormat` is empty it falls back to a
`REGEXP_REPLACE(...) LIKE` query against stripped digits (see
`buildContactSearchCondition` in `src/connectors/netsuite/index.ts`) instead of the
exact-match loop.

## What does this CRM call a contact?

Before implementing `findContact`/`findContactWithName`/`createContact`, ask what
vocabulary the target CRM itself uses for its contact-equivalent record — don't default
to borrowed terminology from another connector (e.g. a recruiting CRM's "candidate"
leaking into an unrelated connector's variable names, or a legal CRM's "matter contact"
leaking into a helpdesk connector). Two questions, not one:

- Does this CRM expose multiple, structurally different contact-like resources behind
  separate API endpoints (Bullhorn's `candidate` vs. `client`, or Zendesk's `requester`
  vs. `organization`, for example)? If so, this is a structural distinction, not just
  vocabulary — the code genuinely needs separate logic paths, and those paths should use
  the CRM's real names since they map to different endpoints/schemas.
- What does the CRM call its single contact-equivalent record, if there's only one? Use
  that name for manifest titles/descriptions and `returnMessage`/UI copy only.

Keep internal code identifiers, comments, and variable names generic/abstract
(`contact`, `matchedRecord`, and so on) regardless of the CRM's own vocabulary — that's
what keeps generated code consistent and reusable across connectors. Reserve
CRM-specific naming in code only where the distinction is structural (the two-endpoint
cases above), not cosmetic.

## Interfaces

**`findContact({ user, authHeader, phoneNumber, overridingFormat, isExtension, ... })` — required**
Look up the target CRM for any contact matching `phoneNumber`, using the
exact-vs-fuzzy-matching decision above to decide whether `overridingFormat` needs to
drive a multi-candidate search loop. Returns
`{ successful, matchedContactInfo: [], returnMessage?, extraDataTracking? }`. Each
matched contact must include a `createdDate` (ISO 8601 or unix timestamp) — auto-logging
uses this to resolve which contact is "the" contact when a number matches more than one.
Append a synthetic option `{ id: 'createNewContact', name: 'Create new contact...',
isNewContact: true }` to offer contact creation in the UI — do **not** actually create a
contact inside `findContact` itself; that only happens if `createContact` is
subsequently called.

**`findContactWithName({ user, authHeader, name, ... })` — optional**
Same shape as `findContact` but keyed on a name search instead of phone number, for
manual "search contacts" in the UI. Implement if the target API supports name search and
the manifest sets `page.useContactSearch: true`.

**`createContact({ user, authHeader, phoneNumber, newContactName, ... })` — optional**
Creates a new contact in the target CRM for a previously-unmatched number, invoked when
the user picks the "create new contact" option surfaced by `findContact`. Even when this
ends up out of scope for the final connector's UI, build a minimal version of it first —
the empirical probe above uses it to create a controlled test contact before `findContact`
is finalized.

## Associating calls with related records

If contacts in the target CRM have related records worth linking a call to (a legal
matter, a sales deal, an opportunity), surface those as `additionalInfo` on the matched
contact using `{ const: id, title: displayName, description?, status? }` entries. Mark
the corresponding manifest field `contactDependent: true` (or `contactTypeDependent:
true` if the available options vary by contact type) so the call-logging UI renders them
as a picker. The user's selection comes back to `createCallLog` as
`additionalSubmission` — that wiring belongs to appconnect-call-logging, but the data
originates here. See `docs/developers/associating-records.md` in the App Connect repo
for the full contract.

`contactDependent`/`contactTypeDependent` fields are undocumented in the shipped `.d.ts`
types — `PageField` is a loose `[key: string]: JsonValue | undefined` interface, so
these fields type-check but give zero IDE guidance. The hosted docs
(`developers/manifest-pages/` and `developers/associating-records/`) are the only
authoritative source. Before implementing any manifest field beyond the basics here,
delegate a fetch of the relevant hosted-docs page to a subagent and ask it to report back
only the condensed schema — these pages are large enough to blow the context budget if
read directly inline.

## Screen-pop / call-pop URL (`contactPageUrl`, `fallbackContactPageUrl`)

A user who just matched a caller to a CRM record will naturally want to click through to
it — cover this alongside contact matching rather than leaving it undiscovered. Elicit
`contactPageUrl` using the shared procedure in `../_shared/url-template-elicitation.md`,
targeting tokens `{hostname}` (or the connector's actual dynamic-environment token),
`{contactId}`, and `{contactType}` (if the CRM has multiple contact types).

### Fallback URL when no contact matches

`findContact` legitimately returns an empty `matchedContactInfo` array whenever a
caller's number isn't in the CRM yet — there's no `contactId` to substitute into
`contactPageUrl` in that case, so call-pop has nothing to open by default. Two manifest
fields cover this: `enableFallbackContactPageUrl` (boolean, default `false`) turns the
behavior on, and `fallbackContactPageUrl` is the fixed URL template call-pop opens
instead. Set both together — enabling the flag without supplying the URL (or the
reverse) leaves the feature half-wired.

Ask the user whether they want call-pop to open something on an unmatched call. If yes,
elicit `fallbackContactPageUrl` with the same procedure as `contactPageUrl` above, but
suggest the CRM's own "create new contact" page as the default starting point — e.g.
Zendesk's `https://{hostname}/agent/users/new` or HubSpot's
`https://{hostname}/contacts/create` — since that lets the agent add the caller on the
spot. This is only a suggestion, not a requirement: the user may point
`fallbackContactPageUrl` at anything else entirely (a saved search, a team dashboard, an
internal wiki page), since it's a fixed destination rather than a per-record deep link.
Only `{hostname}` and custom setting tokens apply here — there's no matched record, so
`{contactId}`/`{contactType}` won't resolve to anything.

## Manual alternative: editing via the Developer Console

If a manifest paste isn't the right move for an already-registered connector (e.g. the
user only has the guided form open, or a full paste risks overwriting unrelated fields
another skill just set), the console's guided form covers everything this skill writes
under one accordion — see `../_shared/developer-console-guide.md` for the full field
map, provenance, and caveats:

- **Contacts** section: Supported contact types (Display/Value rows → `contactTypes[]`),
  Contact page URL (`contactPageUrl`), Enable fallback contact page URL for call-pop
  (`enableFallbackContactPageUrl`), Enable contact search in activity logging
  (`page.useContactSearch`), Disable contact cache.

The shared doc notes the fallback checkbox was captured in its **off** state, so the
paired `fallbackContactPageUrl` text field it reveals when turned on wasn't visible in
that snapshot — confirm the revealed field's exact label live before telling a user
where to paste the fallback URL template from this skill's "Fallback URL when no contact
matches" section above.

## Reference patterns

- `src/connectors/pipedrive`: straightforward phone search against `/v1/persons/search`
  (or v2 equivalent), no related-record complexity, no format-loop (fuzzy-enough API).
- `src/connectors/clio`: exact-match API — uses the alternate-format loop above, then
  for each match fetches related matters and relationships (paginating while a `next`
  cursor exists) to populate `additionalInfo.matters` — a good model for both the
  format-loop and the related-records pattern above.
- `src/connectors/insightly`: exact-match API — same format-loop pattern, simpler
  contact shape than Clio (no related-record fetch).
- `src/connectors/netsuite`: exact-match-when-configured, fuzzy-fallback-otherwise — see
  `buildContactSearchCondition` for the hybrid `LIKE` vs `=` query construction.
- `src/connectors/bullhorn`: contact-dependent fields keyed by manifest `const` names for
  multiple related entity types (candidates, leads, contacts).

## Notes

- Cache lookups where reasonable; `findContact` can be called frequently for the same
  number in a short window.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
