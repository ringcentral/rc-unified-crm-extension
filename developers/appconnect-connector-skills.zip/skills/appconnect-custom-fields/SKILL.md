---
name: appconnect-custom-fields
description: >
  Determines and wires up custom fields on an App Connect connector's logging/creation
  pages (call log, message log, new-contact form) — a dropdown for note type, activity
  type, or outcome — and linking a call or message to a related record (matter, deal,
  ticket). Covers the three field-value sources (static list, per-contact
  additionalInfo, or account-wide cache) and the manifest wiring (contactDependent,
  accountDataKey, accountDataProperty) that connects them to additionalSubmission. Use
  when the user needs a category dropdown on the call or message log, or needs
  calls/messages linked to a matter/deal/ticket, e.g. "add a note-type dropdown to the
  call log", "link calls to the ticket a contact belongs to". Not for the logging
  itself (appconnect-call-logging/appconnect-sms-logging) or contact lookup
  (appconnect-contact-matching) — this only defines fields those read. Runs after
  appconnect-contact-matching and before appconnect-call-logging/appconnect-sms-logging
  via appconnect-build-connector.
---

# App Connect Custom Fields & Record Associations

Shared groundwork for any manifest page that needs a field beyond the basics (log body,
contact) — most commonly the call-logging page, but the same mechanism applies to the
message-log page and the new-contact form. Run this before `appconnect-call-logging` or
`appconnect-sms-logging` so those skills have real fields and real `additionalSubmission`
data to read, instead of guessing at a shape.

## Step 1: Does a custom field exist at all?

Ask the user directly, up front, whether the target CRM's logging screen(s) need any
field beyond the log body itself — the most common example is a dropdown to categorize
the call/message (a note type, activity type, or outcome). If none, skip to Step 2.

If yes, the field's implementation depends entirely on where its list of possible values
comes from — get this right before touching the manifest:

- **Static** — the same enumerated list for every user, on every account (e.g. a fixed
  "Inbound / Outbound / Follow-up" list). Simplest case: set `options: [{const, title}]`
  directly on the manifest field. Clio's `billableStatus` (`billable`/`non-billable`) is
  a shipped example.
- **Per-contact / per-record** — the choices depend on *which* contact, matter, deal, or
  ticket the log is being created against. This is the `contactDependent` /
  `contactTypeDependent` pattern — see Step 2, it's the same mechanism used for record
  association.
- **Account-wide, but not contact-specific** — the list varies by CRM account/tenant
  (often admin-configured), but is identical regardless of which contact/record the log
  is linked to: every user at a given account sees the same options no matter which
  contact or record they're logging against. See "Reference patterns" below for a
  shipped example of this shape.

**Don't conflate the last two.** "Varies by account" does not automatically mean "comes
from `findContact`'s `additionalInfo`" — that mechanism exists specifically for values
tied to *which record is currently matched*, not values that merely differ by account.
Routing an account-wide field through `findContact` means re-fetching (or re-deriving) it
on every contact match for no reason, and it still won't work for a field that has
nothing to do with any contact.

### Per-contact / per-record fields

Mostly built already by `appconnect-contact-matching`, not here — `findContact` returns
`additionalInfo: { <const>: [{ const, title, description?, status? }] }` for the matched
contact, and the manifest field is marked `contactDependent: true` (or
`contactTypeDependent: true` if the options vary by contact type, e.g. on the new-contact
form before a type is even chosen). If `appconnect-contact-matching` already ran for this
connector and surfaced the relevant `additionalInfo`, don't re-derive it — just confirm
the `const` used in the manifest field matches that `additionalInfo` key exactly. This
skill's job is: define the field under the relevant page's `additionalFields[]`
(`page.callLog.additionalFields[]`, `page.messageLog.additionalFields[]`, or
`page.newContact.additionalFields[]`), leaving the reading of the submitted value out of
`additionalSubmission` to whichever downstream skill owns that page
(`appconnect-call-logging`, `appconnect-sms-logging`).

### Account-wide fields

If the picklist is admin-configurable or otherwise account-specific but not tied to any
one contact, it needs an account-level cache instead of `findContact`: fetch the options
from the CRM API once per account, with a TTL (Bullhorn's `noteActions` refreshes every
24h off `settings/commentActionList`), and expose them to the manifest field via
`accountDataKey` / `accountDataProperty` (`accountDataPropertyByContactType` for the
`contactTypeDependent` variant), with `contactDependent: false`.

These two manifest properties are **undocumented** in the hosted manifest doc as of this
writing — don't expect to find them there. Model directly off
`src/connectors/bullhorn/index.ts`'s account-data-registry pattern (`getAccountData` /
the `accountData.bullhornData.fetch` entry) in the `rc-unified-crm-extension` monorepo on
GitHub instead. Confirm the field actually renders a real cached list end-to-end before
considering this done — this pattern isn't documented well enough to trust in the
abstract.

## Step 2: Does a log need to link to a related record?

Ask the user plainly: does a logged call or message need to be associated with some
other record in the CRM beyond the contact itself — a matter, a deal, an opportunity, a
support ticket, or similar? Shipped examples: Clio links calls to "matters" (legal
cases), Pipedrive links to "deals"/"leads".

If yes:

1. Get the CRM's own name for the record type — don't borrow another connector's
   vocabulary (same principle as `appconnect-contact-matching`'s "What does this CRM call
   a contact?" section, applied to the related record instead).
2. Ask the user to point you at the API endpoint that lists/searches these records for a
   given contact (or the relevant slice of an OpenAPI spec), so the association can be
   resolved to an ID.
3. Confirm how the association is expressed on the wire once a log exists — is it a field
   on the call/communication/activity record itself (Clio sets `data.matter.id` on the
   communication), a separate link/join call, or something else? This determines what the
   downstream `createCallLog`/`updateCallLog` (or `createMessageLog`/`updateMessageLog`)
   actually has to send.

This is the same `contactDependent` / `additionalInfo` mechanism as Step 1's per-record
case — `appconnect-contact-matching` owns surfacing the options (see its "Associating
calls with related records" section); this skill owns defining the
`additionalFields[]` entry with the matching `const`. If `appconnect-contact-matching`
hasn't run yet for this connector, say so explicitly — the manifest field alone does
nothing without `findContact` returning the corresponding `additionalInfo` under that
same `const`.

Watch for `contactTypeDependent` cases: if the CRM has multiple contact-like entities
(e.g. two distinct record types that both represent a person), the related-record type
and its options may differ depending on which one was matched. See "Reference patterns"
below for a shipped example of this shape.

## Reference patterns

- `src/connectors/bullhorn`: `noteActions` field sourced from an account-wide cache
  (`settings/commentActionList`, 24h TTL) via `accountDataKey`/`accountDataProperty` —
  the model for Step 1's account-wide case (Bullhorn's "Note type" list is the
  canonical example: it differs account to account, but is identical for every user at
  a given account regardless of which contact they're logging against). Also branches
  contact type across `candidateReference`/`clientContactReference`/`lead` (Bullhorn's
  two contact-like entities, "candidates" and "clients"), feeding `contactTypeDependent`
  fields.
- `src/connectors/clio`: `additionalInfo.matters` surfaced from `findContact`, consumed
  via a `contactDependent: true` manifest field — the model for Step 2's record
  association.
- `src/connectors/pipedrive`: `resolveActivityType()` — admin-configured setting first,
  then cached `activityTypes` keyword-matched, then force-refresh — a good model for a
  static-feeling-but-actually-cached activity-type field; also surfaces `deals`/`leads`
  as `contactDependent: true` fields.

## Manual alternative: editing via the Developer Console

An already-registered connector can also get a new field added through the guided form
instead of a full `manifest.json` paste — useful since this skill's fields are exactly
the kind of small, incremental addition (one dropdown, one association) that's easy to
get wrong hand-editing raw JSON. See `../_shared/developer-console-guide.md` for the
full field map, provenance, and caveats:

- **Activity logging – call logging page** / **message logging page** sections → "Page
  content" list → "Add item" → the **Selection Dropdown** field editor (Field Key,
  Label, Contact dependent, Allow custom value, Show if contact type, Default/Message/
  Voicemail/Fax setting ID) is the guided-form equivalent of one `additionalFields[]`
  entry under `page.callLog`/`page.messageLog`.
- **Admin settings** section → **Account data sources** ("Add account data source") —
  this looks like the guided form's entry point for exactly the `accountDataKey`/
  `accountDataProperty` mechanism this skill currently documents as *undocumented in the
  hosted manifest doc, model off Bullhorn's source instead*. If confirmed live, wiring an
  account-wide cached picklist through this UI is likely faster and less error-prone than
  hand-writing the Bullhorn-style JSON from scratch — but verify the field shape actually
  produces `accountDataKey`/`accountDataProperty` (rather than something else) before
  treating this as the primary path over the source-modeled approach above.

## Handoff

Once fields are defined in the manifest, hand off to whichever page-owning skill needs
them: `appconnect-call-logging` for `page.callLog.additionalFields[]`,
`appconnect-sms-logging` for `page.messageLog.additionalFields[]`. Those skills read the
user's submitted values out of `additionalSubmission`, keyed by each field's `const` —
this skill doesn't touch that runtime code itself.

## Notes

- Don't invent manifest field names from memory — cross-check
  `https://ringcentral.github.io/rc-unified-crm-extension/developers/manifest/` and
  `https://ringcentral.github.io/rc-unified-crm-extension/developers/associating-records/`
  before writing. `accountDataKey`/`accountDataProperty` are the one exception — they're
  real (see Bullhorn) but not in the hosted docs, so go to source instead.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
