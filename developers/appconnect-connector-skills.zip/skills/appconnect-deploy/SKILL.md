---
name: appconnect-deploy
description: >
  Finalizes hosting for a scaffolded App Connect connector — asks where the connector
  will be deployed (AWS Lambda, Azure App Service, or Heroku), then trims the project
  down to only that path: deleting the unused cloud-deploy scaffolding the
  `@app-connect/cli` template ships with by default, and authoring Heroku deploy files
  from scratch since the template has no Heroku support. Use as the last step of a
  connector build, e.g. "where should this connector be deployed", "clean up the deploy
  folders", "set up Heroku deploy for my connector", "I only need Azure, remove the AWS
  stuff". Always runs last via appconnect-build-connector, after every selected feature
  skill — deploy shape doesn't depend on which interfaces got implemented, so there's no
  reason to decide it earlier.
---

# App Connect Deploy

The `@app-connect/cli` template scaffolds **every** connector with both `azure-deploy/`
(a README) and `serverless-deploy/` (AWS Lambda via the Serverless Framework, plus
`src/lambda.ts` and the `serverless-build`/`serverless-deploy` npm scripts) — regardless
of where the connector will actually run. This skill's job is to ask once, then remove
whichever path the user didn't pick. Heroku isn't in the template at all, so if the user
picks it, this skill writes that scaffolding from scratch.

This skill only ever edits files inside the **generated connector project** (e.g.
`appconnect-<crm>-connector/`) — never `rc-unified-crm-extension` itself. That repo's
`packages/template/` is the upstream source the CLI pulls from; changing it there would
affect every future connector, which is out of scope for a per-connector deploy choice.

## Step 1: Ask where this will be hosted

Ask directly — don't infer from context (e.g. don't assume Azure just because the user
mentioned `.NET` elsewhere):

- **AWS Lambda (serverless)** — keeps `serverless-deploy/`, `src/lambda.ts`, and the
  `serverless-build`/`serverless-deploy` scripts already in the template.
- **Azure App Service** — keeps `azure-deploy/README.md`, drops the Lambda/serverless
  path entirely.
- **Heroku** — not in the template. This skill authors `Procfile`, `app.json`, and a new
  `heroku-deploy/README.md`, and drops both the Azure and AWS paths.
- **Not sure yet** — if the user genuinely doesn't know, skip Step 2's cleanup and leave
  all three paths available. Say so explicitly in the Step 4 handoff so a future session
  knows this was deferred on purpose, not missed.

## Step 2: Confirm what gets deleted before deleting it

This is destructive — echo the exact file/directory list for the *un*chosen path(s) and
get explicit confirmation before removing anything, the same gate other skills in this
plugin use for destructive or hard-to-reverse actions.

**If Azure chosen**, remove:
- `serverless-deploy/` (whole directory)
- `src/lambda.ts`
- `scripts/serverless-build.ts`, `scripts/serverless-deploy.ts`
- From `package.json`: the `serverless`, `serverless-deployment-bucket`,
  `serverless-plugin-log-retention` devDependencies and the `serverless-http`
  dependency; rewrite the `build`/`deploy` scripts to drop the
  `serverless-build.js`/`serverless-deploy.js` calls (e.g. `build` becomes just
  `build:ts`, and `deploy` can be removed entirely — Azure deploy methods are
  push/CLI-driven per `azure-deploy/README.md`, not an npm script).

**If AWS chosen**, remove:
- `azure-deploy/` (whole directory)
- Nothing else needs to change — the template's `build`/`deploy` scripts and
  `src/lambda.ts` already target this path.

**If Heroku chosen**, remove everything both other paths would remove:
- `azure-deploy/`, `serverless-deploy/`, `src/lambda.ts`,
  `scripts/serverless-build.ts`, `scripts/serverless-deploy.ts`
- The same `package.json` dependency/script cleanup as the Azure case above, plus set
  `deploy` to a comment-only placeholder or remove it — Heroku deploys via `git push
  heroku <branch>`, not an npm script.

After deleting, tell the user to run `npm install` to reconcile `node_modules` and the
lockfile with the trimmed `package.json` — don't run it yourself as part of cleanup
unless asked, since it can be slow and the user may want to review the diff first.

## Step 3: Author Heroku scaffolding (only if Heroku was chosen)

The connector already binds to `process.env.PORT` and `process.env.APP_HOST` in
`src/server.ts` (see `docs/developers/deploy.md` in the App Connect repo for the full env
var list) — Heroku injects `PORT` automatically, so no source change is needed there.
Don't edit `src/server.ts` or any other interface/logic file as part of this step.

Create these three files:

1. **`Procfile`** (project root):
   ```
   web: npm run prod
   ```

2. **`app.json`** (project root) — declares the required config vars so `heroku
   config:set` (or the Heroku Dashboard) has a checklist to work from. Base the variable
   list on `docs/developers/deploy.md`'s Environment Variables table (`APP_SERVER`,
   `APP_SERVER_SECRET_KEY`, `DATABASE_URL`, plus whatever CRM OAuth variables this
   connector's `getOauthInfo()` actually reads) — don't invent variables that aren't
   referenced in this connector's own code.

3. **`heroku-deploy/README.md`** — mirror the structure of the existing
   `azure-deploy/README.md` (prerequisites, deploy methods, environment variable setup,
   post-deploy verification) but for Heroku specifically:
   - Prereqs: Heroku CLI installed, `heroku login`, `heroku create <app-name>`.
   - Deploy methods: `git push heroku main` (Git-based, the primary path), and the
     GitHub-integration option (Heroku Dashboard → Deploy tab → connect repo → enable
     automatic deploys) as an alternative.
   - Config vars: `heroku config:set APP_HOST=0.0.0.0` is required — Heroku's router
     expects the dyno to bind to all interfaces, not `localhost`. Call this out
     explicitly since it's easy to miss and the app will otherwise fail health checks.
     Set the rest of the required vars from `app.json` the same way.
   - Verification: hit `https://<app-name>.herokuapp.com/isAlive` and
     `/implementedInterfaces?platform=<name>`, same checklist as
     `docs/developers/deploy.md`'s Deployment Checklist.

## Step 4: Update the connector's own README, then hand off

Add a one-line pointer in the connector's `README.md` to whichever deploy folder is now
the only one present (`azure-deploy/README.md`, `serverless-deploy/` +
`docs/developers/deploy.md`'s AWS section, or `heroku-deploy/README.md`).

Report what was removed, what was added (Heroku case only), and where the deploy
instructions now live.

## Progress tracking

If `PROGRESS.md` exists in the project root, update it now that this step is complete,
following the shared mechanics in `../_shared/progress-tracking.md` (mark this skill's
line `[x]` under `## Plan`, add a dated `## Completed steps` entry) with these
deploy-specific differences:

1. The completed-steps entry should record which hosting target was chosen, and what
   got removed/added.
2. This is the last step in the build — set `## Status` to `Build complete`, not `Ready
   for '<next skill>' step`.
3. If the user chose "not sure yet" in Step 1, note that explicitly under `## Issues` so
   a future session knows deploy cleanup is still open, and set `## Status` to `Blocked
   after 'appconnect-deploy' step — see Issues below` instead of `Build complete`.

Then stop and summarize, same as every other skill in this plugin. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside `appconnect-build-connector`),
skip this section entirely.
