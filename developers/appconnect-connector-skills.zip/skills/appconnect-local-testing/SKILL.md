---
name: appconnect-local-testing
description: >
  Walks the user through running the connector's local dev server, tunneling it with
  ngrok, registering it in the App Connect Developer Console, and verifying the auth
  flow actually logs in from a real App Connect client — before further interface work
  is attempted. Use right after appconnect-auth, when the user needs to test
  login/OAuth against a live client, e.g. "let's test auth", "how do I run this
  locally", "set up ngrok for my connector", "register my connector in the Developer
  Console", "make sure login actually works", or "I want to try this for real before we
  keep building". Not for implementing the auth interfaces themselves (appconnect-auth)
  — this only verifies a working implementation end-to-end. Usually runs right after
  appconnect-auth and before appconnect-contact-matching via appconnect-build-connector
  — auth is the one interface every other feature depends on, so proving it works here
  catches problems before they compound.
---

# App Connect Local Testing

Auth is implemented but untested against anything real — everything so far has been
code and, at best, a mocked Jest test. Before writing another line of interface code,
switch gears and prove the login flow works from inside an actual App Connect client
talking to the actual connector server. If auth doesn't work here, nothing built on top
of it (contact matching, call logging, everything else) will work either, and it's far
cheaper to find that out now than three skills from now.

**This skill runs mostly on the user's own machine, not in the agent's sandbox.** The
connector's dev server and the ngrok tunnel both need to keep running continuously while
the user drives a browser/App Connect client against them — a sandboxed shell call that
returns and exits after each command can't hold a long-running process open, and it has
no way to show the user a browser. So this skill is a guided walkthrough: give the user
exact commands and exact console steps, then stop and wait for them to report back what
happened (a URL, a success/failure, an error message) before moving to the next step.
Don't try to run the server or ngrok yourself in the sandbox and don't guess at what the
user saw — ask.

## Step 1: Confirm auth is actually ready to test

Before starting, confirm appconnect-auth's own handoff condition was met: `getUserInfo`
returns a working user object (id, name, timezone), and `getAuthType`/`getOauthInfo` or
`getBasicAuth` are implemented for whichever auth type this connector uses. If
`PROGRESS.md` exists, its `## Status` line reading `Ready for 'appconnect-local-testing'
step` (or equivalent) is enough confirmation. If auth isn't actually done yet, stop and
send the user back to appconnect-auth — testing an incomplete auth implementation just
wastes this step's setup work.

## Step 2: Install and configure ngrok

Check whether ngrok is already available: ask the user to run `ngrok version` in their
own terminal. If it's missing:

- macOS: `brew install ngrok`
- Other platforms: point the user at `https://ngrok.com/download`, or `npm install -g
  ngrok` if they'd rather install it as a devDependency of the connector project itself
  (this is the same `ngrok` package appconnect-setup already flagged as a common
  install-time failure on restricted networks — if it failed there, a system-level
  install per the platform instructions above is the fallback).

ngrok now requires a free account and an authtoken even for basic HTTP tunneling. If the
user hasn't done this before:

1. Have them sign up at `https://dashboard.ngrok.com/signup` (free tier is sufficient).
2. Have them copy their authtoken from `https://dashboard.ngrok.com/get-started/your-authtoken`.
3. Have them run `ngrok config add-authtoken <token>` once, locally — this persists to
   ngrok's own config file, not to anything in the connector project, and only needs to
   happen once per machine.

Don't ask for the authtoken value itself — it's a personal credential tied to the user's
ngrok account, not something this skill needs to see or store.

## Step 3: Start the connector's local server

Find the dev script in the project's `package.json` (`npm run dev` is the convention
appconnect-setup scaffolds) and the port it listens on (check `.env`, `package.json`, or
the server's own startup log — don't assume `3000` without confirming). Ask the user to
run the dev command in its own terminal tab/window and leave it running, then confirm it
started cleanly (no crash, a "listening on port ..." log line or equivalent).

## Step 4: Start an ngrok tunnel and collect the public URL

In a second terminal tab, have the user run:

```bash
ngrok http <port>
```

using the port confirmed in Step 3. Ask them to paste back the `https://` forwarding URL
ngrok prints (something like `https://a1b2c3d4.ngrok-free.app`) — that's the connector's
public address for the rest of this skill.

Flag this now so it doesn't cause confusion later: on ngrok's free tier, that URL is
**ephemeral** — it changes every time the tunnel is restarted. Restarting the tunnel
later (a laptop sleep, a crashed process, a new day) means repeating Step 5 (manifest
edit) and Step 7's paste-into-console (the Developer Console entry itself doesn't need
to be recreated, just updated with the new URL). A paid ngrok plan with a static domain
avoids this churn — mention it as an option, not a requirement.

## Step 5: Point the manifest at the tunnel

Edit `manifest.json`'s top-level `serverUrl` field to the ngrok URL from Step 4, per the
hosted manifest doc
(`https://ringcentral.github.io/rc-unified-crm-extension/developers/manifest/`). If
`manifest.json` doesn't exist yet (appconnect-auth's Step 5 creates a minimal skeleton
the first time an auth block is added — it should exist by now, but don't assume),
that's a sign appconnect-auth didn't fully complete; stop and check rather than
inventing a manifest here.

## Step 6: Log into the App Connect Developer Console

Direct the user to the App Connect Developer Console
(`https://appconnect.labs.ringcentral.com`, or wherever their organization's instance
lives if different) and confirm they're logged in with developer access before
continuing.

## Step 7: Register the connector

Walk the user through these console steps in order, confirming each one before moving
to the next rather than listing them all at once and assuming they'll happen correctly
unattended:

1. Click **Create new connector**.
2. Click the **View source** button — this switches the console from its guided
   form-based UI to a raw JSON editor for the manifest.
3. Copy the entire current contents of the local project's `manifest.json` and paste it
   into the console's editor, replacing whatever placeholder is there.
4. Click **Save**.

Tell the user plainly that it's expected for this manifest to be incomplete at this
stage — only the auth block matters for this test. Contact matching, call logging, and
everything else will still be missing, and that's fine; this step only needs login to
work.

**This full-JSON paste is specifically for first-time registration**, when nothing else
exists yet to preserve. For every later skill's manifest changes to this *already-
registered* connector, re-pasting the whole file isn't the only option and isn't always
the best one — it risks clobbering another skill's fields with a stale local copy, or
may not be available if the user only has the guided form open. Point later skills at
`../_shared/developer-console-guide.md`, which maps each guided-form field back to its
manifest.json property, so an incremental update can go through the form instead.

## Step 8: Connect from the App Connect client

Ask the user to open the App Connect client (the RingEX app/extension where connectors
actually run), find the newly-registered connector, and attempt to sign in using the
auth flow just implemented — OAuth redirect or the API-key/credential form, depending on
what Step 5/6 of appconnect-auth built.

## Step 9: Confirm auth end-to-end and stop

Ask the user directly whether login succeeded. Don't infer success from silence or
assume a lack of error means it worked — get an explicit answer.

- **If it worked:** ask them to confirm the name/identity shown in the client matches
  what `getUserInfo` should be returning. This is the real confirmation that
  appconnect-auth's Handoff condition holds outside of mocked tests — the server was hit
  by a real client through a real network path, not just Jest.
- **If it didn't:** ask for the exact error text shown in the client, and check the
  connector server's terminal output for a stack trace or logged request at the same
  time — the mismatch between what the client shows and what the server actually logged
  is usually where the real cause is. Common culprits, roughly in order of frequency:
  - **OAuth redirect URI mismatch** — the OAuth app's registered redirect URI still
    points at an old ngrok URL, or at `localhost`. Since the tunnel URL changes on
    restart (Step 4), this is worth checking first if auth previously worked and stopped
    after a restart.
  - **Manifest/console out of sync** — Step 5's edit happened after Step 7's paste, so
    the console still has the old `serverUrl`. Re-paste the current manifest.
  - **Wrong header name/scheme on an API-key connector** — re-check the exact header and
    encoding against Step 1/2 of appconnect-auth rather than guessing again here.
  - **ngrok free-tier interstitial page** — some ngrok free URLs show a browser warning
    page on first visit that can interfere with non-browser requests (like an OAuth
    token exchange); the `ngrok-skip-browser-warning` header or a paid plan avoids this.

Don't move on to appconnect-contact-matching until login genuinely succeeds — this is a
hard gate, not a soft recommendation, for the same reason appconnect-auth's own Handoff
section is a hard gate.

## Handoff

Auth is now confirmed working from a real client through a real network path, not just
unit tests. Everything downstream (contact matching, call logging, and so on) can be
exercised live using this same running server, ngrok tunnel, and registered Developer
Console connector — the user doesn't need to repeat this whole setup for every future
skill, only re-point the manifest/console at a new ngrok URL if the tunnel gets
restarted (Step 4's caveat).

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
