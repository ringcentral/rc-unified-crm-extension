---
name: appconnect-readiness
description: >
  Assesses whether a CRM or business API is compatible with the RingCentral App
  Connect framework by analyzing its API spec, producing a structured readiness
  report of which endpoints satisfy which App Connect capabilities (auth, contact
  lookup, call logging, message logging, appointments, admin settings). Use before
  a new connector build whenever the user wants a feasibility check first — e.g.
  "is Zendesk a good fit for App Connect", "check if this CRM's API supports what
  we need", "assess readiness for a HubSpot connector", "compare these two CRMs for
  App Connect support". Also use if the user hands you an OpenAPI/Swagger spec and
  asks what it can/can't do for a connector, even without saying "readiness".
  Standalone and optional — never auto-invoked by appconnect-build-connector, and
  doesn't scaffold a project or write PROGRESS.md. Run appconnect-build-connector
  afterward using this skill's report as input.
---

# App Connect Readiness Assessment

Answer one question before anyone commits to a build: **can this CRM's API actually
support what App Connect needs, and where exactly in its spec does that live?** Produce
a durable, structured report that a human can read for the verdict and that
`appconnect-build-connector` and its per-feature children can later read instead of
re-parsing the CRM's API spec themselves.

## Scope

This skill only assesses. It does **not**:

- Scaffold a project, write any connector code, or touch `PROGRESS.md`. If a connector
  project already exists for this CRM, the only thing this skill writes into it is a
  copy of the report (see Step 10) — never source files or manifest changes.
- Make a final auth-type decision. It recommends, with rationale; the
  `appconnect-build-connector` interview decides.
- Guarantee correctness beyond what the spec (and, optionally, a handful of live calls)
  can verify. Every finding gets an explicit confidence label — never state a finding
  more confidently than the evidence supports.

If the user actually wants to start building, hand off to `appconnect-build-connector`
once this report exists — don't build anything yourself.

## Step 1: Elicit inputs (one form, not a drip of questions)

Ask all of these together, the same way `appconnect-build-connector`'s Step 2 does —
skip anything already answered in the conversation:

1. **CRM/product name** — used for the report title and file name.
2. **API spec source** — a URL to an OpenAPI/Swagger document, or a local file path. If
   neither exists, say so; the docs-only fallback in Failure modes below covers that
   case instead of blocking here.
3. **Assessment depth** — `quick` / `standard` (default) / `comprehensive`. Explain the
   tradeoff briefly (see Step 2) so the choice is informed, not arbitrary.
4. **Capabilities to assess** — default to the full set in Step 3 below; let the user
   trim it if they already know they don't need something (e.g. "skip appointments").
5. **Known auth preference**, if any — e.g. "we want OAuth" — so Step 7 verifies a
   stated preference rather than exploring blind.
6. **Live-verification allowed?** — default no. Only relevant if they have sandbox/dev
   credentials handy; see Step 9.

## Step 2: Depth levels — a hard cap, not a suggestion

Cost scales fast with depth, so treat whichever level the user picked as a ceiling for
this run, not a floor to exceed "just in case":

- **quick**: Step 4 (structural index) + Step 5 (shortlist) + a one-line plausibility
  judgment per capability. No deep schema reads. Minutes, cheap.
- **standard** (default): adds Step 6 (targeted deep verification), but scoped only to
  *required* capabilities — auth, `findContact`, `createCallLog`/`updateCallLog`.
- **comprehensive**: adds Step 6 for every selected capability (including optional
  ones), and enables Step 9 live verification if credentials are available.

If Step 4 reveals more than roughly 300 operations in the spec, stop and tell the user
the estimated cost of going past `quick` before proceeding — don't silently escalate.

## Step 3: The capability checklist

Reuse the exact interface names from the App Connect connector interfaces, so the
report maps 1:1 onto what each feature skill will need:

- **Auth**: OAuth 2.0 (which grant types), API key, Basic — `getAuthType`,
  `getOauthInfo`/`getBasicAuth`, `checkAndRefreshAccessToken`
- **Contact matching**: `findContact`, `findContactWithName`, `createContact`
- **Call logging**: `createCallLog`, `updateCallLog`, `getCallLog`,
  `upsertCallDisposition`
- **Message logging**: `createMessageLog`, `updateMessageLog`
- **Appointments**: `listAppointments`, `createAppointment`, `updateAppointment`,
  `cancelAppointment`, `confirmAppointment`
- **Admin/settings**: `getUserList`, `getLicenseStatus`, `getServerLoggingSettings`,
  `updateServerLoggingSettings`, `getManagedAuthOptions`

Auth and `findContact`/`createCallLog`/`updateCallLog` are required for any connector;
everything else is assessed only if the user kept it in scope (Step 1.4).

## Step 4: Acquire the spec and index it structurally — cheap, always

The hard rule for this whole skill: **never read the raw spec file with a
document-reading tool, and never paste its contents into context.** Specs regularly run
to tens of thousands of lines; loading one wholesale defeats the entire cost-conscious
design here. Use `scripts/spec_helper.py` for all mechanical parsing instead — it does
the work in the shell and prints only small, targeted slices.

1. If the spec is a URL, fetch it to a local file first (`curl -sL <url> -o spec.yaml`).
   If the fetch fails, don't retry blindly — ask the user for a local file instead (see
   Failure modes below).
2. Run `python3 scripts/spec_helper.py stats <file>` first. This tells you the format
   (OpenAPI 3.x vs Swagger 2.0 vs unparseable), operation count, and whether it flags a
   likely multi-file spec (external `$ref`s) — all of which change how the rest of this
   run should proceed. If it can't parse the file, or the format is genuinely
   unrecognizable, fall through to Step 9's docs-only mode.
3. Run `python3 scripts/spec_helper.py toc <file>` to get the full table of contents —
   one line per operation: method, path, operationId, tags, summary. This ToC (not the
   raw spec) is what enters context from here on.

## Step 5: Shortlist candidates per capability — cheap, heuristic

For each capability in scope, scan the ToC for plausible matches by keyword/tag — e.g.
for `findContact`: paths, tags, or summaries containing "search", "contact",
"customer", "user", "lookup". Shortlist 1-5 candidates per capability. Not zero (that's
premature "gap"), not the whole spec (that's the expensive read Step 6 exists to
avoid).

Write down *why* each candidate was shortlisted (which keyword/tag matched) — this
reasoning belongs in the final report so a human can audit it later instead of taking
the verdict on faith.

## Step 6: Targeted deep verification — expensive, scoped only to the shortlist

Only for capabilities Step 2's depth level actually calls for: run
`python3 scripts/spec_helper.py operation <file> <METHOD> <path>` on each shortlisted
candidate. This resolves `$ref` pointers inline so you see the real parameter and
response shape without manually chasing references through the document.

Classify each capability from what you see:

- **Verified** — the spec clearly and directly supports it (a purpose-built endpoint
  with the right shape).
- **Inferred** — plausible via a workaround, e.g. modeling a call as a generic
  note/comment object rather than a purpose-built activity type. Not a purpose-built
  endpoint, but usable.
- **Gap** — nothing in the spec covers it. Record this as a real limitation, not a
  silent omission — a downstream skill needs to know "confirmed absent," not just
  "wasn't found in this pass."

Never run `operation` in a loop over every shortlisted candidate for a capability once
one clearly Verified match is found — stop at the first strong match unless the depth
level calls for surveying alternatives.

## Step 7: Auth deep-dive

Run `python3 scripts/spec_helper.py security <file>` to get the security schemes (or
Swagger 2 `securityDefinitions`) plus any declared `security` requirements. From that:

- Enumerate grant types, `authorizationUrl`/`tokenUrl`, and scopes.
- Cross-check against the user's stated auth preference (Step 1.5), if given;
  otherwise produce a recommendation with rationale (prefer OAuth 2.0 with refresh
  tokens when available — it's what `appconnect-auth` is best set up to implement).
- Note refresh-token behavior and token lifetime if the spec or linked docs state it;
  if they don't, say so explicitly rather than assuming a default.
- If multiple schemes are declared with no clear default, or none are declared at all,
  surface this as an open question (Step 9) rather than guessing.

## Step 8: Gap analysis & workarounds

For every required capability that landed as Inferred or Gap, write an explicit,
concrete recommendation — never just "this might not work":

- Good: "No native call-activity object; model calls as ticket comments tagged
  `[Call]`, using custom field `cf_disposition` for disposition."
- Not good enough: "Call logging may need a workaround."

If a gap is severe enough that it should change the recommended build scope (e.g. no
workaround is credible for disposition tracking), say so plainly and recommend skipping
that optional feature in the `appconnect-build-connector` interview rather than forcing
a fragile implementation later.

## Step 9: Optional live verification

Only if the user set `live-verification: true` (Step 1.6) **and** sandbox/dev
credentials are actually available. Make a small number of real calls against the
shortlisted, high-confidence endpoints to catch spec drift — stale docs, undocumented
required parameters, real rate-limit headers. This is never required for a complete
report; label every finding "verified from spec" vs "verified live" so a reader (human
or downstream skill) knows exactly how much to trust it. See
`references/open-design-questions.md` for the open question about whether this phase
should be more than opt-in in a future version.

## Step 10: Write the report

Full structure and field-by-field guidance: `references/report-template.md`. Read it
now if you haven't already — don't reconstruct the schema from memory, since the
Endpoint Reference Index block must be valid YAML that a downstream skill can parse
programmatically.

**File name/location**: `appconnect-readiness-<crm-key>.md`, written to the current
working directory by default (a connector project may not exist yet). If a connector
project *does* already exist for this CRM, offer to also copy it into that project as
`docs/APPCONNECT_READINESS.md` — that's the conventional path other `appconnect-*`
skills should eventually check for (see the Non-goals reminder below).

## Step 11: Handoff summary

Close with a one-paragraph go/no-go verdict, plus a pre-filled recommendation for the
`appconnect-build-connector` interview: auth type, admin-managed vs per-user, which
optional features are actually feasible to build and which aren't worth attempting.
The goal is that when the user runs the build interview next, it goes faster and
better-informed because this groundwork already exists.

## Caching — check before re-running

If a readiness report already exists for this CRM/spec-source combination, check the
spec's version field (`info.version` from `spec_helper.py stats`) or the file's content
hash before redoing the whole assessment. If the spec hasn't changed, reuse the
existing report and say so — don't silently redo expensive work, and don't silently
skip a refresh either if the user explicitly asked for one.

## Failure modes — handle explicitly, don't improvise mid-run

- **No machine-readable spec available (docs pages only)**: fall back to a lighter
  "docs scan" mode instead of blocking — ask the user for the key doc URLs per
  capability, summarize what those pages say, and mark every finding "Inferred from
  documentation, not a verified spec." This is a legitimate, lower-confidence path
  through the skill, not a dead end.
- **Spec is enormous or split across multiple files** (external `$ref`s):
  `spec_helper.py stats` flags this. Warn the user before committing to `comprehensive`
  depth — multi-file resolution is exactly the kind of thing that quietly balloons cost.
- **Spec fetch fails, spec is Swagger 2.0 instead of OpenAPI 3, or auth is ambiguous**:
  each of these already has its own handling earlier in the skill (Step 4 for fetch
  failures and format detection, Step 7 for ambiguous auth) — this list only covers
  failure modes that don't already have an obvious home in the numbered steps.

## Notes

- The whole point of the phased design (Steps 4-9) is cost control: cheap structural
  passes first, expensive targeted reads only for shortlisted candidates. If you notice
  yourself about to read every operation "just to be thorough," that's the failure mode
  this skill exists to prevent — stop and reconsider the shortlist instead.
- `scripts/spec_helper.py` requires PyYAML for `.yaml`/`.yml` specs
  (`pip install pyyaml --break-system-packages` if missing); `.json` specs work with no
  extra dependency.
- Unresolved product questions about this skill's future shape (live verification by
  default, partial re-runs, a shared reports location) live in
  `references/open-design-questions.md` — don't resolve them by guessing if they come
  up mid-run; ask the user.

## Non-goals reminder

This skill never writes or edits `PROGRESS.md`, never scaffolds a project, and never
edits another `appconnect-*` skill. `appconnect-build-connector`'s own Step 1 checks for
`docs/APPCONNECT_READINESS.md` (or `appconnect-readiness-<crm-key>.md`) and pre-fills its
elicitation from it — but that check lives entirely in the orchestrator's file, not here.
