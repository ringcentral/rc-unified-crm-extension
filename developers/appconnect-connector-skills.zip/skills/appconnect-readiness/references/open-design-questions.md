# Open design questions

These are unresolved product decisions carried over from the original skill spec.
They are deliberately **not** answered here — don't guess at a resolution mid-run.
If one becomes directly relevant during an assessment (e.g. the user asks to
re-check just one capability), surface it to the user as a question rather than
picking a default silently.

1. **Live verification in v1** — should Step 9 (making real test API calls against
   a sandbox account) ship now, or wait until there's evidence spec drift is common
   enough in practice to justify the extra complexity and credential handling? For
   now, Step 9 only runs when the user explicitly sets `live-verification: true`
   and has usable credentials — treat that as an opt-in experiment, not a proven
   default.
2. **Partial re-runs** — should a user be able to say "re-check call logging only"
   and get just that section refreshed, without redoing the whole report? Not
   built yet. If asked for this, be upfront that today the whole report gets
   regenerated, and ask whether that's acceptable before proceeding.
3. **Long-term home for reports with no connector project yet** — right now
   reports for a CRM that has no scaffolded connector live wherever the skill was
   run (the current working directory). Whether there should eventually be a
   shared readiness-reports folder outside any single connector repo is still
   undecided — don't invent one; just tell the user where the file landed.
