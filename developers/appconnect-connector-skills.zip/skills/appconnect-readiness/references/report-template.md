# Readiness report template

This is the exact structure for `appconnect-readiness-<crm-key>.md` (Step 10). Fill
every section — if a section has nothing to say at the chosen depth level (e.g. `quick`
skips deep verification), say so explicitly rather than omitting the heading, so a
reader can tell "nothing found" apart from "not assessed at this depth."

```markdown
# App Connect Readiness Report: <CRM Name>

## Metadata
- CRM: <name>
- Spec source: <url or path>
- Spec format: OpenAPI 3.x / Swagger 2.0 / none (docs-only)
- Spec size: <N paths, size on disk>
- Assessment depth: quick | standard | comprehensive
- Assessed on: <date>
- Overall verdict: Compatible / Compatible with workarounds / Not recommended

## Executive Summary
(3-6 sentences: overall fit, biggest risks/gaps, recommended path forward)

## Auth Assessment
- Supported grant types / schemes: ...
- Recommended choice: ... (with rationale)
- Spec references: securityScheme key, authorizationUrl, tokenUrl, scopes
- Confidence: Verified from spec / Inferred / Needs manual verification
- Risks: refresh behavior, token lifetime, rate limits on token endpoint

## Capability Matrix
| App Connect Interface | Required? | Supported? | Confidence | Primary Spec Reference | Notes |
|---|---|---|---|---|---|
| findContact | Required | ... | ... | `GET /path` (operationId: `x`) | ... |
| createCallLog / updateCallLog | Required | ... | ... | ... | ... |
| (one row per assessed capability) | | | | | |

## Endpoint Reference Index
Machine-scannable block so downstream skills can jump straight to the right
spec location without re-parsing the whole document:

​```yaml
findContact:
  operationId: search
  path: /api/v2/search
  method: GET
  spec_pointer: "#/paths/~1api~1v2~1search/get"
  response_schema_ref: "#/components/schemas/SearchResults"
  key_params: [query, type]
createCallLog:
  operationId: <...>
  path: <...>
  method: <...>
  spec_pointer: <...>
  notes: <workaround description if Inferred>
​```
(one entry per assessed capability, including capabilities marked as Gap —
recorded as `status: gap` with no spec_pointer, so a downstream skill doesn't
waste time re-searching for something already confirmed absent)

## Gaps & Workarounds
(explicit, concrete recommendations — see SKILL.md Step 8)

## Open Questions / Needs Manual Verification
(anything spec-alone couldn't settle — rate limits not documented, behavior
that needs a live sandbox account to confirm, ambiguous pagination model, etc.)

## Recommended Build-Connector Inputs
- Auth type: ...
- Admin-managed: yes/no
- Recommended optional features to include: ...
- Recommended optional features to skip (and why): ...
```

## Notes on filling this in

- **Capability Matrix rows**: include every capability that was in scope for this
  assessment (see the user's Section-3 elicitation answer), not just the required
  ones — an optional capability the user cared enough to ask about deserves a row
  even if the depth level didn't reach full Step 6 verification for it (mark
  Confidence accordingly, e.g. "Not assessed at `quick` depth").
- **Endpoint Reference Index**: this must be valid YAML on its own — a downstream
  skill may parse it programmatically rather than reading the prose above it. Don't
  let it drift out of sync with the Capability Matrix; they describe the same
  findings at two levels of detail (human-readable vs machine-readable).
- **Gap entries**: still get an entry in the YAML block (`status: gap`, no
  `spec_pointer`) — the point is that a downstream skill sees "already checked,
  confirmed absent" instead of re-deriving that from scratch.
