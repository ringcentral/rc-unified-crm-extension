#!/usr/bin/env python3
"""
spec_helper.py — structural indexing and targeted extraction for OpenAPI 3.x /
Swagger 2.0 specs, built for the appconnect-readiness skill.

Why this exists: the readiness skill must never load a full API spec into the
model's context (specs can run to tens of thousands of lines). This script does
the mechanical parsing in the shell instead, and only ever prints small,
targeted slices — a table of contents, a security-scheme summary, or a single
resolved operation — so the model only ever sees what it actually needs for the
phase it's in.

Usage:
    python3 spec_helper.py toc <spec-file>
        Step 4. Prints one line per operation: METHOD PATH operationId | tags | summary
        Also prints a header line with total path count and detected spec format.

    python3 spec_helper.py security <spec-file>
        Step 7. Prints the security schemes / definitions block (OpenAPI 3
        components.securitySchemes, or Swagger 2 securityDefinitions), plus any
        top-level or operation-level `security` requirements referencing them.

    python3 spec_helper.py operation <spec-file> <METHOD> <path>
        Step 6. Prints the full resolved operation object for one method+path
        pair — parameters, requestBody/schema, responses, security — with all
        $ref pointers in that subtree resolved inline. This is the only command
        that should be run once a capability's candidate has been shortlisted;
        never run it in a loop over every operation.

    python3 spec_helper.py stats <spec-file>
        Quick size/shape summary: path count, format, whether the spec is
        split across multiple files (external $refs), title/version. Useful
        for the ~300-path depth-tradeoff check before committing to
        'standard' or 'comprehensive' depth.

All commands accept a local file path (.json, .yaml, or .yml). If you only have
a URL, fetch it first (e.g. `curl -sL <url> -o spec.yaml`) — this script
intentionally does no network access itself, so failures are easy to attribute.
"""
import sys
import json
import os

try:
    import yaml
except ImportError:
    yaml = None


def load_spec(path):
    if not os.path.isfile(path):
        sys.exit(f"error: no such file: {path}")
    with open(path, "r") as f:
        text = f.read()
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        return json.loads(text)
    if ext in (".yaml", ".yml"):
        if yaml is None:
            sys.exit(
                "error: PyYAML not installed. Run: pip install pyyaml --break-system-packages"
            )
        return yaml.safe_load(text)
    # Unknown extension — sniff it.
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        if yaml is None:
            sys.exit(
                "error: couldn't parse as JSON and PyYAML isn't installed to try YAML. "
                "Run: pip install pyyaml --break-system-packages"
            )
        return yaml.safe_load(text)


def detect_format(spec):
    if "openapi" in spec:
        return f"OpenAPI {spec.get('openapi')}"
    if "swagger" in spec:
        return f"Swagger {spec.get('swagger')}"
    return "unknown (neither `openapi` nor `swagger` top-level key found)"


def resolve_ref(spec, ref, _depth=0):
    """Resolve a local $ref (#/a/b/c) against the root spec document."""
    if _depth > 20:
        return {"$ref_error": f"resolution too deep, possible cycle at {ref}"}
    if not ref.startswith("#/"):
        return {"$ref_external": ref}  # multi-file spec — flag, don't chase across files
    parts = ref.lstrip("#/").split("/")
    node = spec
    for p in parts:
        p = p.replace("~1", "/").replace("~0", "~")
        if isinstance(node, dict) and p in node:
            node = node[p]
        else:
            return {"$ref_error": f"could not resolve {ref}"}
    return deep_resolve(spec, node, _depth + 1)


def deep_resolve(spec, node, _depth=0):
    if _depth > 20:
        return node
    if isinstance(node, dict):
        if "$ref" in node and isinstance(node["$ref"], str):
            return resolve_ref(spec, node["$ref"], _depth + 1)
        return {k: deep_resolve(spec, v, _depth + 1) for k, v in node.items()}
    if isinstance(node, list):
        return [deep_resolve(spec, v, _depth + 1) for v in node]
    return node


HTTP_METHODS = {"get", "put", "post", "delete", "options", "head", "patch", "trace"}


def cmd_stats(spec, path):
    paths = spec.get("paths", {}) or {}
    op_count = sum(1 for p in paths.values() for m in (p or {}) if m.lower() in HTTP_METHODS)
    info = spec.get("info", {}) or {}
    # crude external-$ref scan for multi-file spec detection
    raw = json.dumps(spec)
    external_refs = raw.count('"$ref": "') and any(
        "$ref" in str(v) and not str(v).startswith("#/")
        for v in _walk_refs(spec)
    )
    print(f"format: {detect_format(spec)}")
    print(f"title: {info.get('title', '(none)')}  version: {info.get('version', '(none)')}")
    print(f"paths: {len(paths)}  operations: {op_count}")
    print(f"file size: {os.path.getsize(path)} bytes")
    print(f"external $refs (multi-file spec?): {'yes — investigate before comprehensive depth' if external_refs else 'no'}")
    if op_count > 300:
        print("\n>300 operations — per the readiness skill's cost rules, confirm depth "
              "tradeoff with the user before proceeding past 'quick'.")


def _walk_refs(node):
    if isinstance(node, dict):
        if "$ref" in node:
            yield node["$ref"]
        for v in node.values():
            yield from _walk_refs(v)
    elif isinstance(node, list):
        for v in node:
            yield from _walk_refs(v)


def cmd_toc(spec):
    paths = spec.get("paths", {}) or {}
    print(f"# format: {detect_format(spec)}  paths: {len(paths)}")
    for path, item in paths.items():
        if not isinstance(item, dict):
            continue
        for method, op in item.items():
            if method.lower() not in HTTP_METHODS or not isinstance(op, dict):
                continue
            op_id = op.get("operationId", "")
            tags = ",".join(op.get("tags", []) or [])
            summary = op.get("summary", "") or op.get("description", "")[:80]
            print(f"{method.upper():7} {path:50} op={op_id or '-':30} tags={tags or '-':20} {summary}")


def cmd_security(spec):
    fmt = detect_format(spec)
    print(f"# format: {fmt}")
    if "openapi" in spec:
        schemes = (spec.get("components", {}) or {}).get("securitySchemes", {})
        print("## components.securitySchemes")
    else:
        schemes = spec.get("securityDefinitions", {})
        print("## securityDefinitions")
    print(json.dumps(schemes, indent=2))
    print("\n## top-level `security` requirement")
    print(json.dumps(spec.get("security", "(none declared at top level — check per-operation)"), indent=2))


def cmd_operation(spec, method, path):
    paths = spec.get("paths", {}) or {}
    if path not in paths:
        # tolerate trailing-slash / case mismatches loosely
        candidates = [p for p in paths if p.rstrip("/") == path.rstrip("/")]
        if not candidates:
            sys.exit(f"error: path {path!r} not found in spec. Run `toc` first to get exact paths.")
        path = candidates[0]
    item = paths[path]
    op = item.get(method.lower())
    if op is None:
        sys.exit(f"error: method {method!r} not found on {path!r}. Available: {list(item.keys())}")
    resolved = deep_resolve(spec, op)
    print(json.dumps(resolved, indent=2))


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    command, spec_path = sys.argv[1], sys.argv[2]
    spec = load_spec(spec_path)
    if command == "toc":
        cmd_toc(spec)
    elif command == "security":
        cmd_security(spec)
    elif command == "stats":
        cmd_stats(spec, spec_path)
    elif command == "operation":
        if len(sys.argv) != 5:
            sys.exit("usage: spec_helper.py operation <spec-file> <METHOD> <path>")
        cmd_operation(spec, sys.argv[3], sys.argv[4])
    else:
        print(__doc__)
        sys.exit(f"error: unknown command {command!r}")


if __name__ == "__main__":
    main()
