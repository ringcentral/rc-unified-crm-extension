---
name: appconnect-server-logging
description: >
  Implements server-side call logging for an App Connect connector — the
  serverSideLogging manifest block plus getServerLoggingSettings,
  updateServerLoggingSettings, and (for user mapping) getUserList. Server-side logging
  lets App Connect log calls for an entire organization from the backend, without any
  user having the extension open. Use when the user wants calls logged automatically
  account-wide, needs an admin-configured service-account credential flow, or wants
  RingEX extensions mapped to CRM users so logs land under the right owner — e.g. "add
  server-side logging", "let admins turn on logging for the whole team without the
  extension open", "map RingEX users to CRM users for server logging". Optional — only
  run as part of a full build via appconnect-build-connector if selected in scope. Does
  not cover getLicenseStatus (per-user license gating) — that's appconnect-settings-admin,
  a separate concern.
---

# App Connect Server-Side Call Logging

Optional. Server-side logging lets App Connect's backend subscribe to call events for an
entire RingCentral account and log them directly — no extension needs to be open, and no
individual user needs to be logged into the CRM in their browser. The framework does the
heavy lifting (subscribing to call events, resolving the contact, invoking your existing
`createCallLog`); what a connector author implements is the **configuration layer**: how
the server gets credentials to act autonomously, and optionally how RingEX users map to
CRM users so logged calls land under the right owner.

There are two tiers of implementation, and it's worth being explicit with the user about
which one they're getting:

1. **Toggle only** — declare `serverSideLogging` in the manifest with
   `useAdminAssignedUserToken: true`. The server reuses the admin's own OAuth session to
   log every call. No new interfaces to write. Fast, but every server-logged call is
   attributed to the admin, not the agent who took it.
2. **Full implementation** — `useAdminAssignedUserToken: false` plus
   `getServerLoggingSettings` / `updateServerLoggingSettings` (a service-account
   credential the server can use on its own), and, if per-agent attribution matters,
   `getUserList` with `enableUserMapping: true` so admins can map each RingEX extension to
   a CRM user.

Confirm which tier the user wants before writing anything — don't default to the full
build just because it's more capable.

## Step 0: How does the server log calls at all?

No new logging logic is required here — `createCallLog`/`updateCallLog` from
`appconnect-call-logging` run exactly as they do for client-side logs. The framework:

1. Resolves the contact via the connector's existing `findContact`.
2. Determines the CRM user to attribute the call to, if user mapping is configured.
3. Calls `createCallLog` with the resolved contact, call data, and the raw RingCentral
   extension id (`rcExtensionId`) — using either the admin's stored OAuth token or the
   mapped agent's, depending on `useAdminAssignedUserToken`.

So confirm `appconnect-call-logging` has already run (or is at least designed) before
starting this skill — there's nothing to configure here if `createCallLog` doesn't exist
yet.

## Step 1: Enable it in the manifest

Add a `serverSideLogging` object under the platform in `manifest.json`:

```json
"serverSideLogging": {
  "url": "https://my-connector.example.com",
  "useAdminAssignedUserToken": false,
  "enableUserMapping": true,
  "additionalFields": [
    { "const": "apiUsername", "title": "CRM API Username", "type": "inputField", "required": true },
    { "const": "apiPassword", "title": "CRM API Password", "type": "inputField", "required": true }
  ]
}
```

| Property | Type | Description |
| --- | --- | --- |
| `url` | string | Base URL of the connector's server-side logging endpoint. |
| `useAdminAssignedUserToken` | boolean | `true` → reuse the admin's own OAuth token for every logged call (toggle-only tier, no new interfaces). `false` → the connector supplies its own credentials via `getServerLoggingSettings` (full tier). |
| `enableUserMapping` | boolean | `true` → Admin settings shows a user-mapping table (RingEX extension → CRM user) and `getUserList` is required to populate it. |
| `additionalFields` | array | Fields shown in the Admin settings form when `useAdminAssignedUserToken: false`. Same shape as `page.callLog.additionalFields` (see `appconnect-custom-fields`). Values submitted here arrive at `updateServerLoggingSettings` as `additionalFieldValues`. |

### Determining `useAdminAssignedUserToken`

This isn't purely a preference question — check whether the target CRM's create-call-log
endpoint (whatever `createCallLog` actually calls: an activity, note, or comment object)
accepts an explicit owner/author override that's independent of whichever credentials
authenticated the request:

- **API supports an override field** — e.g. Zendesk's ticket comment `author_id`: per
  Zendesk's own docs, "the user with the id is shown as the author of the comment... the
  authenticated user making the API request is the updater." The API separates *who
  authenticated the call* from *who is credited as the record's author*. When this exists,
  `useAdminAssignedUserToken: true` is viable — the admin's own OAuth token authenticates
  every server-side call, and `createCallLog` still sets the override field to the CRM user
  id resolved via `enableUserMapping`/`getUserList`. Single-admin-token simplicity and
  correct per-agent attribution aren't mutually exclusive here — don't assume they are.
- **No override field; ownership is strictly tied to the authenticating credentials** —
  `useAdminAssignedUserToken: true` then means every record really is admin-owned with no
  way to reassign it, so an `enableUserMapping` table would collect a mapping the connector
  has no mechanism to apply. Set `useAdminAssignedUserToken: false` instead, and confirm
  separately whether the service-account credentials collected via
  `getServerLoggingSettings` carry the same limitation (some CRMs let an admin-scoped API
  key specify an author independent of the key's own identity; others don't). If neither
  path supports it, tell the user per-agent attribution isn't achievable for this CRM
  rather than wiring up `enableUserMapping` for a setting that can't take effect.

Ask the user directly which combination of `useAdminAssignedUserToken` /
`enableUserMapping` they want once you've confirmed which combinations the target API
actually supports — don't infer it from the auth type already configured in
`appconnect-auth`. A connector can be per-user OAuth for the interactive extension and
still use a shared service account for server-side logging, and vice versa.

If `useAdminAssignedUserToken: true` and `enableUserMapping` is not needed (the target API
has no owner/author override, or per-agent attribution isn't wanted), stop here — nothing
else in this skill applies. Update `PROGRESS.md` and move on. If `useAdminAssignedUserToken:
true` but the API *does* support an override field and per-agent attribution is wanted,
continue to `getUserList` below (skip `getServerLoggingSettings`/`updateServerLoggingSettings`
— no service-account credentials are needed when the admin's own token authenticates every
call).

## Interfaces

Skip `getServerLoggingSettings`/`updateServerLoggingSettings` if `useAdminAssignedUserToken:
true` — a service-account credential has nothing to do once the admin's own token is used
for every call. Skip `getUserList` if `enableUserMapping` isn't set.

**`getServerLoggingSettings({ user })`**
Called by the framework whenever it needs the stored server-side credentials — e.g.
before processing a server-logged call, or when rendering the settings UI. Return the
settings object previously saved by `updateServerLoggingSettings`, shaped by whatever
`additionalFields` the manifest declares (typically a service-account username/password,
but can be anything the CRM's API needs):

```js
async function getServerLoggingSettings({ user }) {
  return { apiUsername: 'admin@example.com', apiPassword: 'secret' };
}
```

**`updateServerLoggingSettings({ user, additionalFieldValues, oauthApp })`**
Called when an admin saves the server-side logging form. Persist
`additionalFieldValues` (keys match the manifest's `additionalFields` `const`s) so
`getServerLoggingSettings` can retrieve them later. No return value is required on
success; on failure, throw or return `{ successful: false, returnMessage }`. `oauthApp`
is provided in case the update needs to refresh a token as part of validating the new
credentials — most connectors won't need it.

```js
async function updateServerLoggingSettings({ user, additionalFieldValues }) {
  await ServerLoggingSettings.upsert({
    organizationId: user.organizationId,
    apiUsername: additionalFieldValues.apiUsername,
    apiPassword: additionalFieldValues.apiPassword
  });
}
```

**`getUserList({ user, authHeader, proxyConfig })`** — only if `enableUserMapping: true`

Return the CRM's own user directory so the admin can map each RingEX extension to a CRM
user. Core auto-matches by `email` first, then `name`; admins fix any leftovers by hand.

```js
[{ id: 'crm-user-id', name: 'Jane Smith', email: 'jane@example.com' }]
```

The framework builds `authHeader` for you based on the connector's configured auth type
(bearer OAuth token vs. Basic from an API key) before calling this — don't reimplement
that branching inside `getUserList` itself. If the connector is a **proxy** connector
rather than a standalone code connector, `getUserList` is gated behind
`proxyConfig.operations.getUserList` — the framework silently returns an empty list if
that operation isn't declared on the proxy, so confirm it's present rather than assuming
the interface alone is enough.

## Reference patterns

- `src/connectors/pipedrive/manifest.json`: `serverSideLogging` declared with
  `useAdminAssignedUserToken: false, enableUserMapping: true` and no `additionalFields` —
  Pipedrive's `getServerLoggingSettings` sources credentials from the connector's own
  admin-config storage rather than an admin-entered form field, which is a valid
  alternative to the username/password pattern above when the CRM already has an
  account-level credential on file from `appconnect-auth`.
- `src/connectors/pipedrive/index.ts` `getUserList`: a single filtered `GET
  /api/v1/users` call, excluding `is_deleted` records — the simple case for CRMs with a
  small, single-page user list.
- `src/connectors/bullhorn/index.ts` `getUserList`: paginates through
  `query/CorporateUser` with a `start`/`count` cursor and a hard loop cap (500
  iterations) as a safety net against a runaway pagination bug — the pattern to reach for
  when the CRM's user list can be large enough to require paging.
- **Known gap:** no shipped connector in `rc-unified-crm-extension` currently implements
  `getServerLoggingSettings`/`updateServerLoggingSettings` — only the manifest toggle and
  `getUserList` have real examples. Design the credential-storage shape from the
  `additionalFields` contract above rather than looking for a reference implementation to
  copy.
- **Zendesk (`appconnect-zendesk-connector`, external code-connector repo):** the ticket
  comment API's `author_id` field is a real example of the "override field" case in
  [Determining `useAdminAssignedUserToken`](#determining-useadminassignedusertoken) above
  — it lets an admin-authenticated request credit a comment to a different user. As of
  this writing, that connector's `createCallLog.ts` does not yet set `author_id` (its only
  per-record override is `requester_id`, used to attach the *caller's* contact to a new
  ticket, not to attribute authorship to the *agent*) — so per-agent attribution via
  server-side logging is not yet wired up there even though the underlying Zendesk API
  supports it. Don't treat its current state as a "no" answer to the override-field
  question above; treat it as an unimplemented "yes."

## Manual alternative: editing via the Developer Console

See `../_shared/developer-console-guide.md` for the full field map, provenance, and
caveats. The **Server-side logging** section covers this skill's whole manifest surface:

- Enable server-side logging (checkbox) — the `serverSideLogging` block's presence.
- Enable admin assigned owner (checkbox) — **naming ambiguity flagged in the shared
  doc**: its help text doesn't map cleanly 1:1 onto this skill's
  `useAdminAssignedUserToken`/`enableUserMapping` pair. Don't tell a user this checkbox
  is definitely `useAdminAssignedUserToken` without checking it against a live console
  session next to a known manifest first.
- Enable user mapping (checkbox) → `enableUserMapping`.
- "Customize the server-side logging settings page" → Page content list → `additionalFields[]`.

## Standalone runs: files to read first

If this skill runs outside `appconnect-build-connector` (no `PROGRESS.md` to read for
state), go directly to these rather than a full-repo exploration subagent:

- `manifest.json` — confirm `serverSideLogging` isn't already declared, and check
  `page.callLog.additionalFields` for the `additionalFields` shape convention this
  connector already uses.
- `getServerLoggingSettings.ts` / `updateServerLoggingSettings.ts` / `getUserList.ts`
  (exact paths per the scaffolded template's connector structure).
- `findContact.ts` and the connector's `createCallLog.ts` — server-side logging calls
  both directly; confirm they don't assume a browser session or any client-only context
  (e.g. a value only available from the extension's UI state) that won't exist when the
  framework invokes them server-side.

## Notes

- `getLicenseStatus` (per-user license gating before logging on someone's behalf) is a
  separate, independently optional interface — it lives in `appconnect-settings-admin`,
  not here. Only bring it in if the target CRM has per-seat licensing that should block
  server-side logging for unlicensed users.
- Don't invent field names from memory — confirm current signatures against
  `docs/developers/server-side-logging.md` and the corresponding
  `docs/developers/interfaces/*.md` files before implementing.
- Credentials collected via `additionalFields` are account/organization-scoped, not
  per-user — treat them with the same care as any service-account secret (never logged,
  never echoed back in a settings-read response beyond what the admin UI needs).

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
don't skip persistence outright — offer to create or append to a lightweight `TODO.md`/
notes file instead, recording which tier was implemented (toggle-only vs. full) and
whether user mapping was included.
