---
name: appconnect-settings-admin
description: >
  Implements custom user/admin settings, per-user license gating, and dynamic
  managed-auth options for an App Connect connector — manifest settings sections,
  onUpdateUserSettings, getLicenseStatus, and getManagedAuthOptions. Use when the user
  needs configurable per-user or per-account settings, a per-seat license check before an
  operation proceeds, or a searchable admin-managed auth field, e.g. "add a setting to
  toggle X", "gate this feature by license", "make the dealer ID field searchable for
  admins". Optional — only run this as part of a full build via appconnect-build-connector
  if the user selected these features in scope. For admin-driven server-side call
  logging (the serverSideLogging manifest block, getServerLoggingSettings,
  updateServerLoggingSettings, getUserList), use appconnect-server-logging instead —
  that content moved to its own skill.
---

# App Connect Settings & Admin Features

Optional, and somewhat of a grab-bag — these interfaces share a theme (admin/account-level
configuration) more than a single interface signature. Server-side call logging used to
live here too; it's now `appconnect-server-logging` since it grew enough surface area
(manifest toggle, credential storage, user mapping) to warrant its own skill.

## Custom settings

Settings live under `platforms.<name>.settings[]` in the manifest as sections
containing items of type `inputField`, `boolean`, `option` (single or multi-select
checkbox), or `warning`. Visible to end users by default unless the item sets
`visibleToUsers: false` (admin-only). Read a setting's current value at runtime via
`user.userSettings?.<settingId>?.value`, and reference it in URL templates
(`contactPageUrl`, `logPageUrl`) with `{settingId}` tokens. Implement
`onUpdateUserSettings({ user, userSettings, updatedSettings })` if a settings change
needs validation or a side effect (e.g. re-fetching data when a hostname setting
changes). See `docs/developers/custom-settings.md` in the App Connect repo for the full
schema.

## Per-user license gating

If the target CRM has per-user licensing that gates access to its API (a paid-tier seat,
an admin-only role, etc.), implement:

- **`getLicenseStatus({ userId, platform, user })`** — returns
  `{ isLicenseValid, licenseStatus, licenseStatusDescription }` for the connected CRM
  user. The framework calls this before operations that should be blocked for
  unlicensed users; a missing user record resolves to
  `{ isLicenseValid: false, licenseStatus: 'Invalid (User not found)' }` automatically.

This is independently optional from everything else in this skill — implement it any time
the CRM has seat-based licensing, whether or not server-side logging (which also has an
optional, separate use for it — see `appconnect-server-logging`) is in scope. Confirm the
exact signature against `docs/developers/interfaces/getLicenseStatus.md` before
implementing; if an interface can't proceed due to licensing, surface it as a normal
`returnMessage` from that interface rather than throwing.

## Dynamic managed-auth options

If appconnect-auth set up a managed API-key field with `managedFieldType: "dynamic"`
(user-scoped managed values that need to be looked up rather than typed, e.g. picking
from a list of dealer IDs), implement:

- **`getManagedAuthOptions({ user, additionalInfo })`** — returns the searchable list of
  choices for that field.

This interface is listed under auth in the platform docs but is implemented here since
it's really a settings-admin concern (an admin curating a list) more than a core
authentication concern.

## Manual alternative: editing via the Developer Console

The guided form covers this skill's manifest surface under two accordions — see
`../_shared/developer-console-guide.md` for the full field map, provenance, and caveats
(both were captured empty/entry-point-only in the reference snapshot, so the per-item
sub-fields below aren't fully documented there yet — confirm live when actually adding
one):

- **Custom settings** section → "Add Setting Section" — the guided-form path for a
  `platforms.<name>.settings[]` section (`inputField`/`boolean`/`option`/`warning` items,
  `visibleToUsers` for admin-only).
- **Admin settings** section → **Standalone admin settings** ("Add standalone setting")
  for settings not tied to an account data source, or **Account data sources** ("Add
  account data source") if the setting instead needs a server-provided option list —
  note the latter may also be the guided-form path for `accountDataKey`/
  `accountDataProperty` that `appconnect-custom-fields` uses; see that skill's own
  Developer Console section rather than duplicating the caveat here.

No console section was identified for `getManagedAuthOptions`' dynamic managed-auth
field in this reference snapshot (it was captured with an OAuth connector, and dynamic
managed fields apply to API-key auth) — if this comes up, check whether it appears
somewhere under **Authentication** once "Static credentials" is selected, and update the
shared doc once confirmed rather than guessing here.

## Notes

- Confirm exact manifest field names and interface signatures against
  `docs/developers/custom-settings.md` and the corresponding
  `docs/developers/interfaces/*.md` files — this area has more manifest-schema surface
  area than code, so getting the JSON shape right matters more than the implementation
  logic.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely.
