---
name: appconnect-setup
description: >
  Scaffolds a new, standalone App Connect code-connector project using the
  `@app-connect/cli` template: derives the project name from the target CRM, handles
  directory/name collisions, initializes git and a GitHub repo, installs dependencies,
  and prepares the local `.env`. Use when the user is starting a brand-new App Connect
  connector and needs the initial project structure in place, or says things like "set
  up the project for my new connector", "scaffold the Foo connector", "get my dev
  environment ready for App Connect". Not for implementing any interface logic (auth,
  contact-matching, call-logging, etc.) — this skill produces the scaffold only. Usually
  invoked by appconnect-build-connector as the first step of a build, but can run
  standalone if the user just wants the skeleton.
---

# App Connect Setup

Get a new connector from zero to "runs locally and can be pointed at from a Developer
Console profile." Don't implement any real interface logic here — that's the job of the
auth/contact-matching/call-logging/etc. skills. This skill produces the scaffold only.

## Scope

This skill only builds **standalone, code connectors**:

- **Standalone**: its own project/repo created from the `@app-connect/cli` template —
  never a connector bundled inside a checkout of `rc-unified-crm-extension` itself. Per
  this project's own rules, the `rc-unified-crm-extension` source is never edited.
- **Code connector**: a real Node.js/Express server implementing the connector
  interfaces in TypeScript — not a **proxy connector** (a pure `proxyConfig` JSON
  definition with no server, configured entirely in the Developer Console).

**Disclaimer:** this skill (and the auth/contact-matching/call-logging skills it hands
off to) does not currently support proxy connectors. If the user wants a proxy
connector — likely a good fit if the target CRM has simple, predictable REST endpoints
and no need for custom retry/token-refresh/multi-call logic — point them at
`docs/developers/proxy-connector.md` in the App Connect repo instead of running this
skill.

## Step 1: Get the CRM name

Ask only for the target CRM/platform name (e.g. "Zendesk"). Derive from it:

- **Connector key**: camelCase, e.g. `zendesk` — used in code and manifest.
- **Project/directory name**: `appconnect-<crm>-connector` (kebab-case), e.g.
  `appconnect-zendesk-connector`.

Don't ask for a bundled-vs-standalone choice — this skill is standalone-only (see
Scope above).

## Step 2: Handle name/directory collisions

Before scaffolding, check whether `appconnect-<crm>-connector` already exists in the
current working directory's parent (or wherever new projects get created).

If it exists:

1. Inspect the existing directory (package.json name/description, README, git remote,
   `src/connectors/*` contents) to figure out whether it's a prior/parallel attempt at
   this same connector, or something unrelated that happens to collide.
2. Tell the user what you found, then ask them to choose:
   - **Overwrite and start over** — only if they confirm the existing directory is
     abandoned/stale work they're fine losing. On some mounted/shared folders, an
     outright delete isn't permitted (write/overwrite/rename works, `rm`/`unlink`
     doesn't) — if a straight delete fails, rename the old directory aside (e.g. append
     `-old-<timestamp>`) instead of fighting the restriction, then scaffold fresh into
     the original name.
   - **Use an alternative unique name** — suggest the pattern
     `appconnect-<crm>-connector-2` (incrementing further if that's also taken).

Don't guess silently in either direction — a wrong guess here means scaffolding on top
of (or discarding) someone else's work.

## Step 3: Scaffold from the template

**Preflight network check — do this first, before running `npx`.** `@app-connect/cli
init` downloads its template from GitHub (`github.com/.../archive/*.tar.gz`, which
redirects to `codeload.github.com`), not from npm; `npm install` right after talks to
`registry.npmjs.org` instead. Sandboxed environments (including Claude's Cowork sandbox)
often allowlist one of these hosts and block the other — and that failure otherwise only
surfaces after `npx`/`npm` has already resolved, installed, and started work, which burns
real time and tokens before failing. Check both cheaply first:

```bash
curl -sI --max-time 5 https://codeload.github.com -o /dev/null -w '%{http_code}\n'
curl -sI --max-time 5 https://registry.npmjs.org -o /dev/null -w '%{http_code}\n'
```

- Any HTTP status code (even a 4xx) means the host is reachable — proceed with the
  scaffold command below.
- A curl error (timeout, connection refused, DNS failure, exit code non-zero with no
  status line) means that download will fail the same way. Don't retry, and don't try to
  route around it (mirrors, raw IPs, alternate hosts, `--registry` tricks) — in this
  environment it's a deliberate network policy, not a transient glitch.
- A TLS/certificate error specifically on the npm check (not a timeout, not a connection
  refusal) usually isn't a block — see "Corporate proxy / self-signed TLS on npm" under
  Troubleshooting notes below before treating it as a hard stop.

If blocked, stop immediately and tell the user directly: scaffolding needs to reach
GitHub's archive endpoints and/or the npm registry, which this sandbox doesn't allow.
Then ask how they'd like to proceed — don't ask this before probing, since whether
there's a real decision to make depends on the probe result:

- **Guide me** — print the exact commands below for the user to run themselves, in any
  environment with unrestricted network (their own machine, a CI runner, etc.), then pick
  back up at Step 4 once they confirm the project directory exists.
- **Hand me the archive** — if the user has another way to get the template tarball into
  the workspace folder (an internal mirror, VPN access, a teammate's existing clone),
  unpack/proceed from there instead.

**Scaffold in a scratch directory first, then move the result into place — this is the
default, not a fallback.** Never run `init`/`npm install` directly inside the final
target directory. Two failure modes make in-place scaffolding risky: the CLI's own
collision handling can try to `rm -rf` an existing target (fails with `EBUSY`/`EPERM` on
some filesystems and on mounted folders that disallow delete), and a partially-failed
`npm install` run in place can leave a corrupted `node_modules` that looks like a real
dependency problem rather than what it is. Scaffolding in scratch sidesteps both:

```bash
scratch=$(mktemp -d)
npx @app-connect/cli init "$scratch/<project-name>"
cd "$scratch/<project-name>"
npm install
cd -
mv "$scratch/<project-name>" <target-parent-dir>/<project-name>
```

`mv` is a rename, not a delete-then-write, so it works even on mounts that block
`unlink`/`rm` — only fall back to scaffolding directly in place if scratch space
(`mktemp`) isn't available at all.

Default to **npm** as the package manager unless the user says otherwise.

Verify the generated project's Node.js version requirement against the live
`getting-started.md` prerequisites rather than assuming a fixed version — check it with
`node -v` and flag a mismatch instead of hardcoding an expected version in this skill.

**Non-critical dependency failures — don't chase them to ground.** If `npm install`
fails on one specific package rather than erroring out entirely, check whether that
package is a core runtime dependency of the generated connector (in `dependencies`) or
incidental dev tooling (a devDependency like `ngrok` for local tunneling, or a
native-build package like `sqlite3`). For the latter category:

- Spend at most one or two commands confirming it's isolated to that one package —
  don't root-cause it further. A single failing optional dependency is usually
  environment-specific (missing build toolchain, a proxy blocking one tarball host) and
  not something this skill can fix generically.
- Log it plainly in the Step 5 handoff report as a known issue for the user's own
  machine (e.g. "`npm install` succeeded except for `ngrok`, which failed to download
  its binary — install it separately if you need local tunneling") and move on.
- Only treat it as blocking if the generated server actually fails to start because of
  it (`npm run dev` errors as a result) — verify that before deciding it's blocking,
  don't assume.

## Step 4: Local dev hygiene

- Confirm/add a `.gitignore` covering `node_modules/`, `.env`, build output (e.g.
  `dist/`), and `.DS_Store` — the template should already ignore most of these, but
  verify rather than assume.
- Create `.env` from the template's `.env.test` (`cp .env.test .env`, or
  `Copy-Item .env.test .env` on Windows). Leave the actual values for the auth skill to
  fill in — this step just makes sure the file exists and is already git-ignored. This
  local `.env` is distinct from the deployed-secrets configuration described in
  `docs/developers/deploy.md` (that covers env vars for the App Connect *server*
  deployment, not a connector project's local dev secrets) — don't conflate the two.
- Write a short starter README (project name, one-line description, how to run
  `npm run dev`) if the template doesn't already include one worth keeping.
- Initialize git if not already initialized by the CLI, and make an initial commit.
- If the user has a GitHub repo URL for this project, add it as the `origin` remote
  (don't push automatically — confirm with the user first).

## Step 5: Hand off

Report what was created (directory, files, initial commit) and confirm the connector
key before the auth skill runs — that decision is load-bearing for everything
downstream. Mention that once auth is implemented, appconnect-local-testing walks
through standing up an HTTPS tunnel (ngrok or similar — redirect URIs generally can't
point at plain `localhost`), registering a Developer Console connector profile, and
verifying login end-to-end — nothing needs to be set up manually here.

## Troubleshooting notes

These are sandbox/network artifacts rather than scaffolding-logic problems — don't
restructure this skill around them, just recognize them fast if they come up. Both
network failure modes below are things the Step 3 preflight check will already have
surfaced; this section only adds the fix once you know which one you're looking at.

- **Corporate proxy / self-signed TLS on npm** (a certificate-trust error, not a timeout
  or connection refusal) — the environment likely sits behind a proxy presenting its own
  cert. `npm config set strict-ssl false` (or pointing `cafile` at the proxy's cert,
  the safer fix if you have it) resolves it. Treat `strict-ssl false` as a last resort
  and tell the user it weakens npm's transport security for that session.
- **`codeload.github.com` blocked while `registry.npmjs.org` is reachable** (the Step 3
  preflight check passed for npm but failed for codeload, or `npx @app-connect/cli init`
  hangs/fails opaquely despite both passing) — `git clone` the template repo directly
  instead of relying on the CLI's own tarball fetch.
- **A single devDependency (e.g. `ngrok`) fails to install and re-fails identically even
  in a clean directory** — a proxy-level policy block on that specific package, not a
  registry or npm bug, and not fixable from inside this skill. See "Non-critical
  dependency failures" in Step 3 for how much effort this is worth before logging it and
  moving on.

## Notes

- Don't guess at exact CLI commands, package names, or manifest field names if the docs
  are available to check — this skill's job is scaffolding correctness, and a wrong
  scaffold compounds into every later step.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
skip this section entirely — but if you're the one that just scaffolded the project
(this is appconnect-setup) and the orchestrator handed you a confirmed plan, that plan is
what seeds `PROGRESS.md` in the first place — see appconnect-build-connector's own Step 4.
