---
name: appconnect-sms-logging
description: >
  Implements SMS/message logging for an App Connect connector — createMessageLog and
  updateMessageLog. Use when the user needs text messages (or fax/voicemail, which share
  the same interface) written to the CRM as notes/activities/records, grouped by
  conversation rather than logged one row per message, e.g. "add SMS logging to my
  connector", "log text messages to the CRM", "group texts by conversation like the call
  logging does". Optional — only run this as part of a full build via
  appconnect-build-connector if the user selected SMS logging in scope.
---

# App Connect SMS/Message Logging

Optional but common. The interface pair mirrors call logging (`createMessageLog` /
`updateMessageLog`), and reuses call logging's decisions on log format and custom fields
wholesale — nothing new to design there. What's genuinely new here: what CRM object a
*conversation* becomes (often not the same object calls log into), and the
conversation-append logic itself, which has no shared core helper and every shipped
connector hand-rolls independently.

## The flow

The first message in a new conversation/day group calls `createMessageLog`. Subsequent
messages in that same group call `updateMessageLog`, which fetches the existing log and
splices the new message into it rather than creating a new record each time.
`messageType` is derived from which optional param is populated, not passed explicitly:
`recordingLink` present → voicemail, `faxDocLink` present → fax, neither → SMS. So this
same interface pair is what "voicemail logging" and "fax logging" mean too — confirm with
the user in Step 1 whether those are in scope alongside SMS, since scoping to "SMS only"
changes what `createMessageLog` needs to branch on.

Shared/team SMS numbers (multiple agents texting from one line) use a
`sharedSMSLogContent` override — when populated, it replaces the entire composed
body/subject/`conversationCreatedDate` rather than being merged in. Ask in Step 3 whether
this applies.

**Custom fields and record associations are handled by `appconnect-custom-fields`, not
here** — same boundary as call logging. If the target CRM needs a note-type dropdown on
the message-logging page, or texts need to link to a matter/deal/ticket, that skill
defines `page.messageLog.additionalFields[]` and this skill's interfaces just read
`additionalSubmission`, keyed by whatever `const` that skill chose.

Before writing any code, work through Steps 0–3 below with the user.

## Step 0: What does a conversation become in this CRM?

Don't assume it's the same object call logging uses — it often isn't. Ask directly, the
same way call logging's Step 0 asks about a native call/activity object. Shipped
examples span a wide range:

- Bullhorn, Redtail: an HTML note/activity, appended to with `<li>`/`<ul>` markup.
- Clio: a `Communication` record (the same entity type call logging uses there).
- Insightly: an `Event` linked to the contact/lead.
- Netsuite: a `phonecall` record, plain-text append.
- Pipedrive: an activity whose type is resolved via a `pipedriveSMSActivityType` setting
  and must contain "sms".
- Vinsolutions: the Lead's own `notes` field — creating the Lead first if none exists yet
  for that phone number.
- Google Sheets: no note-like object at all — a dedicated "Message Log" sheet, one **row**
  per conversation, with updates patching cells on that row by ID rather than appending
  text.

If the CRM's message-equivalent object is append-only (can't be PATCHed once created —
common in ticketing/case systems), reuse call logging's "append-only logging pattern"
rather than re-deriving it here: `updateMessageLog` posts a new distinguishable entry
instead of editing the first one, and `getCallLog`-equivalent lookups exist to find the
latest entry, not to merge into it.

## Step 1: Scope — SMS only, or also voicemail/fax through this same interface?

Ask directly. Because `messageType` is inferred from `recordingLink`/`faxDocLink`
presence rather than passed as an explicit flag, "add SMS logging" and "add voicemail/fax
logging" are the same implementation work here, not separate features. Confirm which of
the three the user actually wants before writing the branch logic in `createMessageLog` —
scoping to SMS-only still means checking for and ignoring (or explicitly rejecting) the
other two params.

## Step 2: Conversation-append logic — design it, don't assume a shared helper exists

**There is no core utility for this.** Every shipped connector reimplements its own
"find the existing log → splice in the new message → return the updated body" logic:
marker-delimited blocks (Bullhorn/Redtail's `BEGIN...END`, with a
"Conversation(N messages)" counter incremented on each update), plain-text append with a
separator (Insightly, Netsuite), or a row-patch for tabular models (Google Sheets). This
is a known gap — filed as a feature request in `extra-features.md` in the
rc-unified-crm-extension repo, proposing a shared append helper in `@app-connect/core` —
but it hasn't landed, so design this per-connector for now:

1. Pick a format matching the CRM's actual capability (from `getLogFormatType`, reused
   from call logging — see Step 4): HTML marker block with a message counter, or a
   plain-text separator-delimited append.
2. Decide the grouping window. Shipped connectors group by conversation *and* reset at a
   day boundary (a new day starts a new log even mid-conversation) to keep any one record
   from growing unbounded — confirm with the user whether day-boundary reset is wanted or
   whether grouping should be conversation-only with no reset.
3. If the CRM object is tabular (no note/activity concept — see Step 0), design an
   update-by-row-ID patch instead of a text splice.

## Step 3: Shared/team SMS handling

Ask whether the target scenario includes a shared/team number multiple users text from.
If so, `sharedSMSLogContent.body`/`.subject`/`.conversationCreatedDate` needs to be
checked first in both interfaces and, when present, used to replace the composed content
outright rather than merged with the per-user composition logic from Step 2. If shared
numbers aren't a scenario for this CRM, skip this and don't implement the branch.

## Step 4: Reuse what call logging already decided

Don't re-elicit these — read them from the earlier build step instead:

- **Log format** (`getLogFormatType`) — the same connector-level function call logging
  implements; message logs use whatever `LOG_DETAILS_FORMAT_TYPE` it returns.
- **Custom fields** (`additionalSubmission`) — same mechanism as call logging, sourced
  from `page.messageLog.additionalFields[]` in the manifest instead of `page.callLog`'s.
  If `appconnect-custom-fields` hasn't run yet and the user asks for a field here, hand
  off rather than improvising the manifest inline.
- **Deep link** — if the conversation lives in the same object type calls log into (e.g.
  Clio's `Communication`), reuse the already-confirmed `logPageUrl` template. If it's a
  different object (e.g. Google Sheets' dedicated sheet), elicit a separate one using the
  same propose → confirm → write gate call logging's Step 2 uses — don't skip the
  confirmation just because the pattern is familiar.

## Interfaces

**`createMessageLog({ user, contactInfo, authHeader, message, additionalSubmission, recordingLink, faxDocLink, correspondents, sharedSMSLogContent, ... })`**
Create the CRM record for the first message in a group. `message` follows the RC
`readMessage` API shape. Returns `{ logId, returnMessage? }` — a missing `logId` is
treated as failure. Per-connector extras seen in shipped code: `imageLink` /
`imageDownloadLink` / `videoLink` / `faxDownloadLink` (Clio), `contactNumber`
(Google Sheets, Netsuite), `hashedAccountId` (Pipedrive).

**`updateMessageLog({ user, contactInfo, authHeader, existingMessageLog, message, sharedSMSLogContent, ... })`**
Append a new message to an existing log for the same conversation/day group.
`existingMessageLog.thirdPartyLogId` is the CRM's own log ID. No return contract is
enforced the way `createMessageLog`'s `logId` is — implement the splice logic from Step 2
here.

## Manual alternative: editing via the Developer Console

See `../_shared/developer-console-guide.md` for the full field map, provenance, and
caveats. This skill's own manifest surface is thinner than call logging's — most of what
touches the message-logging page belongs to a different skill:

- If Step 4 reuses call logging's `logPageUrl`/`canOpenLogPage`/log-format decisions
  wholesale, nothing new needs editing here — those already live under **Activity
  logging (general)**, owned by `appconnect-call-logging`.
- If Step 4 instead needs its own separate deep link (a different underlying CRM object
  than calls log into), that's still the same **Activity logging (general)** section —
  confirm live whether it's one shared field or renders separately per page before
  assuming which.
- Custom fields on the message-logging page (`page.messageLog.additionalFields[]`) are
  the **Activity logging – message logging page** section's "Page content" list, owned
  by `appconnect-custom-fields` — point there rather than describing the field editor
  here.

## Reference patterns

- `src/connectors/bullhorn`: `Note` entity, HTML `BEGIN...END` marker block with a
  "Conversation(N messages)" counter incremented on update.
- `src/connectors/clio`: `Communication` record (+ optional `TimeEntry`), plain-text,
  updated in place.
- `src/connectors/googleSheets`: dedicated "Message Log" sheet — one row per conversation;
  `updateMessageLog` finds the row by ID and patches cells rather than appending text.
  Look here first if the target CRM has no note/activity concept at all.
- `src/connectors/vinsolutions`: creates the Lead if none exists yet for the number, then
  writes via a `composeMessageNote`-style helper into its `notes` field.
- See `appconnect-custom-fields`'s Reference patterns for how `additionalSubmission` keys
  get defined in the manifest in the first place.

## Standalone runs: files to read first

If this skill runs outside `appconnect-build-connector` (no `PROGRESS.md` to read for
state), go directly to these rather than a full-repo exploration subagent:

- `createMessageLog.ts` / `updateMessageLog.ts` (exact paths per the scaffolded
  template's connector structure).
- `manifest.json` — for `page.messageLog` config and any fields
  `appconnect-custom-fields` already defined there.
- The connector's main wiring/index file — for how these interfaces get registered, and
  whatever `getLogFormatType` call logging already implemented.
- `findContact.ts` — for the `contactDependent`/`additionalInfo` shape
  `appconnect-contact-matching` established, since message logging reads the same shape.

## Notes

- Don't invent field names from memory — confirm current names against
  `docs/developers/interfaces/createMessageLog.md` and `updateMessageLog.md` before
  implementing.
- **Known cross-skill gap (core):** no shared helper exists for the conversation-append
  splice logic in Step 2 — every connector hand-rolls it. Filed as a feature request in
  `extra-features.md` (rc-unified-crm-extension repo root, 2026-08-25) proposing a shared
  utility in `@app-connect/core`. Until that lands, this skill must design the append
  logic per-connector rather than pointing to a reusable function.
- **Known cross-skill gap (shared with call logging):** logging to a custom field
  (`additionalSubmission` values from `appconnect-custom-fields`) assumes that field
  already exists in the target CRM account — no `appconnect-*` skill provisions a missing
  field. Same gap `appconnect-call-logging` documents; the fix belongs in
  `appconnect-custom-fields` and/or `appconnect-settings-admin`, not here.

## Progress tracking

If `PROGRESS.md` exists in the project root, follow the shared procedure in
`../_shared/progress-tracking.md` now that this step is complete. If `PROGRESS.md`
doesn't exist (this skill is being run standalone, outside appconnect-build-connector),
don't skip persistence outright — offer to create or append to a lightweight `TODO.md`/
notes file instead, recording the real design decisions made in this run (which object a
conversation maps to, day-boundary reset or not, whether fax/voicemail were included,
whether shared/team SMS applies).
